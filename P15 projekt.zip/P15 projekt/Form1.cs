﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool JePrvocislo(int C)
        {
            for (int i = 2; i < C; i++)
                if ((C / i) == ((float)C / i))
                    return (false);
            return (true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int dolnimez, hornimez, pocet=0;
            long soucet=0;
            float prumer;
            dolnimez=Convert.ToInt32(tbDolniMez.Text);
            hornimez=Convert.ToInt32(tbHorniMez.Text);
            rtbSeznam.Text = "";
            for (int c = dolnimez; c <= hornimez; c++)
            {
                //MessageBox.Show("cislo: "+c.ToString()+" "+JePrvocislo(c).ToString());
                if (JePrvocislo(c))
                {
                    rtbSeznam.Text += c.ToString()+" ";
                    pocet++;
                    soucet += c;
                }
            }
            tbPocet.Text = pocet.ToString();
            prumer = (float)soucet / pocet;
            tBPrumer.Text = prumer.ToString();
        }
    }
}
