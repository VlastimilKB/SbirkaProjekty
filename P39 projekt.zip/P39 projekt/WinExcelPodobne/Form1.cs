﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinExcelPodobne
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();   
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dGV.ColumnCount = 26;           // počet sloupců
            dGV.RowCount = 30;              // počet řádků
            WindowState = FormWindowState.Maximized;
            for (int i = 0; i < 26; i++)            // nadpisy sloupců A,B, ..., Z
            {
                dGV.Columns[i].Name = "  "+Convert.ToString((char)(i + 65));
                dGV.Columns[i].Width = 48;
            }
            for (int i = 0; i < 30; i++)            // nadpisy řádků 1,2, ..., 30
            {                           
                dGV.Rows[i].HeaderCell.Value = Convert.ToString(i + 1);
                dGV.RowHeadersWidth = 48;
            }
            button1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)      // součet hodnot nad aktiv bunkou
        {
            int AktivRadek, AktivSloupec,radekVysledek;
            float Suma = 0, AktivHodnota;

            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            radekVysledek = AktivRadek;
            AktivRadek--;        // cyklus bezi dokud nenajdu prazdnou bunku, 0 je take jako prazdna
            while (Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value) != 0)
            {
                AktivHodnota = Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value);
                Suma += AktivHodnota;               // pripocitam aktivni hodnotu
                AktivRadek--;                       // nastavim se o radek vyse
                if (AktivRadek < 0) goto konec;     // na hornim okraji tabulky musime ukoncit vypocet
            }
            konec: dGV.Rows[radekVysledek].Cells[AktivSloupec].Value = Suma.ToString();
        }

        private void button3_Click(object sender, EventArgs e)      // prumer cisel vlevo od aktivni bunky
        {
            int AktivRadek, AktivSloupec, sloupecVysledek, pocet=0;
            float Suma = 0, AktivHodnota;

            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            sloupecVysledek = AktivSloupec;
            AktivSloupec--;
            while (Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value) != 0)
            {
                AktivHodnota = Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value);
                Suma += AktivHodnota;
                pocet++;
                AktivSloupec--;
                if (AktivSloupec < 0) goto konec;
            }
            konec: dGV.Rows[AktivRadek].Cells[sloupecVysledek].Value = (Suma/pocet).ToString("0.00");
        }




        private void button5_Click(object sender, EventArgs e)  // zjisti pocet hodnot v tabulce ruzne od null
        {
            int PocetHodnot = 0;
            for (int radek = 0; radek < 30; radek++)
                for (int sloupec = 0; sloupec < 26; sloupec++)
                    if (dGV.Rows[radek].Cells[sloupec].Value != null)
                        PocetHodnot++;
            textBox1.Text = PocetHodnot.ToString();
        }






        private void button4_Click(object sender, EventArgs e)      // median nad aktivni bunkou
        {
            List<float> p = new List<float>();
            float Median;
                        // načteme si hodnoty nad aktivní bunkou do seznamu = list p pro snadne setrideni
            int AktivRadek, AktivSloupec, radekVysledek;
            int pocet = 0;
            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            radekVysledek = AktivRadek;
            AktivRadek--;
            while (Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value) != 0)
            {
                p.Add(Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value));
                pocet++;
                AktivRadek--;
                if (AktivRadek < 0) goto konec;
            }
            konec: p.Sort();    // pole hodnot si seřadíme metodou Sort pro seznam - tedy List p
            if (pocet % 2 == 1)      // lichý počet vede na index pocet/2   např. 7/2=3
            {
                dGV.Rows[radekVysledek].Cells[AktivSloupec].Value = p[pocet / 2].ToString();
            }
            else                // sudý počet bereme průměr 2 prostředních hodnot, např. pro 8 -> indexy 3,4
            {
                Median = (p[pocet/2] + p[(pocet/2) - 1])/2;
                dGV.Rows[radekVysledek].Cells[AktivSloupec].Value = Median.ToString();
            } 
        }

        private void button6_Click(object sender, EventArgs e)   // jednotkova matice o rozmeru nad akt.b.
        {
            int aktradek, aktsloupec,rozmermat;
            aktradek = Convert.ToInt16(dGV.CurrentRow.Index);
            aktsloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            rozmermat = Convert.ToInt16(dGV.Rows[aktradek-1].Cells[aktsloupec].Value);
            for (int r = 0; r < rozmermat; r++)
                for (int s = 0; s < rozmermat; s++)
                    if (r == s)
                        dGV.Rows[aktradek + r].Cells[aktsloupec + s].Value = "1";   // pro rovnost indexu je 1
                    else
                        dGV.Rows[aktradek + r].Cells[aktsloupec + s].Value = "0";   // pro ruzne indexy je 0
        }

        private void button7_Click(object sender, EventArgs e)      // převod teplot C na F a opacne
        {
            int AktivRadek, AktivSloupec;
            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            char stupnice;
            float F,C;
            stupnice = Convert.ToChar(dGV.Rows[AktivRadek].Cells[AktivSloupec-1].Value);
            if (stupnice == 'C')
            {
                C = Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec - 2].Value);
                F = (float)9/5 * C + 32;
                dGV.Rows[AktivRadek].Cells[AktivSloupec].Value = F.ToString("0.00");
                dGV.Rows[AktivRadek].Cells[AktivSloupec+1].Value = "F";
            }
            if (stupnice == 'F')
            {
                F = Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec - 2].Value);
                C = (F-32) *(float)5 / 9;
                dGV.Rows[AktivRadek].Cells[AktivSloupec].Value = C.ToString("0.00");
                dGV.Rows[AktivRadek].Cells[AktivSloupec + 1].Value = "C";
            }
        }

        private void button8_Click(object sender, EventArgs e)      // sinus hodnoty nalevo
        {
            int AktivRadek, AktivSloupec;
            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            int uhel;
            double sinus;
            uhel = Convert.ToInt16(dGV.Rows[AktivRadek].Cells[AktivSloupec-1].Value);  // hodnota vlevo
            sinus = Math.Sin(uhel*3.141592653/180);
            dGV.Rows[AktivRadek].Cells[AktivSloupec].Value = sinus.ToString("0.000");
        }

        private void button9_Click(object sender, EventArgs e)      // seřazeni hodnot nad aktivni bunkou
        {                                                           // do sloupce napravo
            List<float> p = new List<float>();
                        // načteme si hodnoty nad aktivní bunkou do seznamu = list p pro snadne setrideni
            int AktivRadek, AktivSloupec, AKTIV;
            int pocet = 0;
            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            AKTIV = AktivRadek;
            AktivRadek--;
            while (Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value) != 0)
            {                                 // nacteme si vsechny hodnoty nad aktivni bunkou do seznamu p
                p.Add(Convert.ToSingle(dGV.Rows[AktivRadek].Cells[AktivSloupec].Value));
                pocet++;
                AktivRadek--;
                if (AktivRadek < 0) goto konec;
            }
        konec: p.Sort();    // pole hodnot si seřadíme metodou Sort pro seznam - tedy List p
                                                // vlozime serazene hodnoty do sloupce napravo
            for (int i = pocet; i > 0; i--)
                dGV.Rows[AKTIV - i].Cells[AktivSloupec+1].Value = p[pocet - i].ToString();
        }

        private double Fakt(int n)
        {
            double f=1.0;
            for (int i = 2; i <= n; i++)
                f *= i;
            return f;
        }

        private void button10_Click(object sender, EventArgs e) // pocet kombinaci n nad k dvou hodnot vlevo
        {
            int AktivRadek, AktivSloupec, n, k; ;
            double nnadk;
            AktivRadek = Convert.ToInt16(dGV.CurrentRow.Index);
            AktivSloupec = Convert.ToInt16(dGV.CurrentCell.ColumnIndex);
            n = Convert.ToInt16(dGV.Rows[AktivRadek].Cells[AktivSloupec-2].Value);
            k = Convert.ToInt16(dGV.Rows[AktivRadek].Cells[AktivSloupec-1].Value);
            nnadk = Fakt(n) / Fakt(k) / Fakt(n-k);
            dGV.Rows[AktivRadek].Cells[AktivSloupec].Value = nnadk.ToString();
        }
    }
}
