﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;                // doplněno kvůli třídě Directory

namespace WindowsFormsAdresarINFO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult vysledek = folderBrowserDialog1.ShowDialog();
            string folderName = folderBrowserDialog1.SelectedPath;
            textBox1.Text = folderName;
            if (folderName == "")
            {
                MessageBox.Show("Nemáte vybraný adresář!");
                return;
            }
            listBox1.Items.Clear();
            int fCount = Directory.GetFiles(folderName, "*", SearchOption.TopDirectoryOnly).Length;     // počet souborů ve složce
            textBox2.Text = fCount.ToString();

            string[] files = System.IO.Directory.GetFiles(folderName, "*.*");   // seznam jmen souborů ve složce
            long maxdelka = 0, aktvelikost;
            string nazevnejdelsiho = "";
            foreach (string s in files)     // projdeme si všechny soubory v adresáři
            {
                System.IO.FileInfo fi = null;
                fi = new System.IO.FileInfo(s);
                aktvelikost = fi.Length;        // velikost souboru
                if (aktvelikost > maxdelka)
                {
                    maxdelka=aktvelikost;
                    nazevnejdelsiho = fi.Name;
                }
                listBox1.Items.Add(fi.Name);
            }
            textBox3.Text = nazevnejdelsiho;
            textBox4.Text = Convert.ToString(maxdelka) +" bytes";
            textBox5.Text = Convert.ToString(maxdelka / 1024) + " kB";

            string[] JPGfiles = System.IO.Directory.GetFiles(folderName, "*.jpg");   // seznam jmen souborů JPG ve složce
            int pocetJPG = 0;
            foreach (string s in JPGfiles)     // projdeme si všechny soubory JPG v adresáři
                pocetJPG++;
            string[] JPEGfiles = System.IO.Directory.GetFiles(folderName, "*.jpeg");   // seznam jmen souborů JPEG ve složce
            foreach (string s in JPEGfiles)     // projdeme si všechny soubory JPEG v adresáři
                pocetJPG++;
            textBox6.Text = pocetJPG.ToString();

            string[] XLSfiles = System.IO.Directory.GetFiles(folderName, "*.xls*");   // seznam jmen souborů XLS ve složce
            int pocetXLS = 0;
            foreach (string s in XLSfiles)     // projdeme si všechny soubory XLS v adresáři
                pocetXLS++;
            textBox7.Text = pocetXLS.ToString();

        }
    }
}
