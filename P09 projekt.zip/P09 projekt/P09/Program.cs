﻿using System;

namespace Prumery
{
    class Program
    {
        static double geoprumer(int[] p)	             // geometrický průměr
        {
            double soucin = 1, prum;
            for (int i = 0; i < 10; i++)
                soucin = soucin * p[i];
            prum = Math.Pow(soucin, 0.1);         // funkce Power je obecna 
            // mocnina, parametr 0.1 je ve významu 10.odmocniny
            return prum;
        }

        static double kvadprumer(int[] p)
        {
            double soucetctvercu = 0, prum;
            for (int i = 0; i < 10; i++)
                soucetctvercu += p[i] * p[i];
            prum = Math.Sqrt(soucetctvercu / 10);	// druhá odmocnina
            return prum;
        }

        static double harmprumer(int[] p)	    // harmonický průměr
        {
            double soucet = 0, prum;
            for (int i = 0; i < 10; i++)
                soucet += 1.0 / p[i];    // sečteme převrácené hodnoty
            prum = 10 / soucet;		// výsledek je počet hodnot / součet
            return prum;
        }

        static double aritprumer(int[] p)         // aritmetický průměr
        {
            double soucet = 0, prum;
            for (int i = 0; i < 10; i++)
                soucet += p[i];	          // soucet = soucet + p[i];
            prum = soucet / 10;
            return prum;
        }

        static void VypisPole(int[] pole)
        {
            foreach (int hodnota in pole)
                Console.Write(hodnota + "  ");
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            int[] pole = new int[] { 10, 14, 13, 15, 8, 9, 16, 12, 7, 9 };
            double GeoPru, KvaPru, HarPru, AriPru;
            Console.Write("Prumery pro tyto hodnoty:  ");
            VypisPole(pole);
            GeoPru = geoprumer(pole);
            Console.WriteLine("geometricky prumer je " +
                               GeoPru.ToString("#0.000"));
            KvaPru = kvadprumer(pole);
            Console.WriteLine("kvadraticky prumer je " +
                               KvaPru.ToString("#0.000"));
            HarPru = harmprumer(pole);
            Console.WriteLine("harmonicky  prumer je " +
                               HarPru.ToString("#0.000"));
            AriPru = aritprumer(pole);
            Console.WriteLine("aritmeticky prumer je " +
                               AriPru.ToString("#0.000"));
            Console.ReadLine();
        }
    }
}

