﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace P28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (FontFamily oneFontFamily in FontFamily.Families)
            {
                listBox1.Items.Add(oneFontFamily.Name);
                // názvy všech dostupných fontů zobrazime v listboxu
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string VybranyFont, Abeceda;
            VybranyFont = listBox1.Items[listBox1.SelectedIndex].ToString();
            tbVybranyFont.Text = VybranyFont;
            Abeceda = "ABCDE... 012345... abcde";
            Font myfont = new Font(VybranyFont, 24.0f);
                                                            // font, velikost pisma
            tbUkazka.Font = myfont;
            tbUkazka.Text = Abeceda;

        }

        int cislofontu = 0, pocetfontu;

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            pocetfontu = listBox1.Items.Count;          
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = cislofontu;  
                                                                // přejdu na další font v seznamu
            cislofontu++;                         
                                                    // zbytek provede udalost SelectedIndexChanged
            if (cislofontu > (pocetfontu-1))
                cislofontu = 0;                 
                            // pokud jsem na konci seznamu fontů, tak se presunu na zacatek
        }
    }
}
