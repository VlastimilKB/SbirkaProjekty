﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckBinNaDekHex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Vypocet()   // obecna funkce, ne udalostni, bude se volat na click na checkboxech
        {
            int hodnota = 0;
            string HexaCifra = "0123456789ABCDEF";      // pripravime si vsechny hexa cifry
            if (checkBox1.Checked) hodnota += 128;
            if (checkBox2.Checked) hodnota += 64;
            if (checkBox3.Checked) hodnota += 32;
            if (checkBox4.Checked) hodnota += 16;
            if (checkBox5.Checked) hodnota += 8;
            if (checkBox6.Checked) hodnota += 4;
            if (checkBox7.Checked) hodnota += 2;
            if (checkBox8.Checked) hodnota += 1;
            tBdekadicka.Text = hodnota.ToString();
            char hex1 = '0', hex2 = '0';
            int h1 = 0, h2 = 0;
            if (checkBox1.Checked) h1 += 8;
            if (checkBox2.Checked) h1 += 4;
            if (checkBox3.Checked) h1 += 2;
            if (checkBox4.Checked) h1 += 1;
            hex1 = HexaCifra[h1];   // vybereme spravnou hexa cifru podle stejneho indexu 0-15

            if (checkBox5.Checked) h2 += 8;
            if (checkBox6.Checked) h2 += 4;
            if (checkBox7.Checked) h2 += 2;
            if (checkBox8.Checked) h2 += 1;
            hex2 = HexaCifra[h2];

            tBhexa.Text = hex1.ToString() + hex2.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int hodnota = 0;
            string HexaCifra = "0123456789ABCDEF";
            if (checkBox1.Checked) hodnota += 128;      // napocitame si dekadickou hodnotu
            if (checkBox2.Checked) hodnota += 64;
            if (checkBox3.Checked) hodnota += 32;
            if (checkBox4.Checked) hodnota += 16;
            if (checkBox5.Checked) hodnota += 8;
            if (checkBox6.Checked) hodnota += 4;
            if (checkBox7.Checked) hodnota += 2;
            if (checkBox8.Checked) hodnota += 1;
            tBdekadicka.Text = hodnota.ToString();
            char hex1='0', hex2='0';
            int h1=0, h2=0;
            if (checkBox1.Checked) h1 += 8;         // prvni hexa cifra jsou prvni 4 bity 8421
            if (checkBox2.Checked) h1 += 4;
            if (checkBox3.Checked) h1 += 2;
            if (checkBox4.Checked) h1 += 1;
            hex1 = HexaCifra[h1];                   // na indexu je hexa hodnota, treba 10 ja "A", ...
            if (checkBox5.Checked) h2 += 8;         // druha hexa cifra jsou posledni 4 bity 8421
            if (checkBox6.Checked) h2 += 4;
            if (checkBox7.Checked) h2 += 2;
            if (checkBox8.Checked) h2 += 1;
            hex2 = HexaCifra[h2];
            tBhexa.Text = hex1.ToString() + hex2.ToString();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            Vypocet();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Visible = false;
        }
    }
}
