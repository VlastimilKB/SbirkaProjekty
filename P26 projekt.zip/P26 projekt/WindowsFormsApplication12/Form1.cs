﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        CheckBox[] t = new CheckBox[50];            // vytvorime v pameti pole checkboxu
        int[] Tazeno = new int[8];                  // funkcni indexy 1 - 6, 7 je doplňkové
        int[] Tip = new int[7];

        int PocetZatrzenych = 0;

        private void cBox_CheckedChanged(object sender, System.EventArgs e)
        {
            int PocZat = 0;
            string TipCis = "";
            for (int i = 1; i < 50; i++)    // při každé změně proberu všechny check boxy
            {
                if (t[i].Checked)
                {
                    PocZat++;
                    if (PocZat > 6)
                    {
                        MessageBox.Show("Mate zatrzeno:" + PocZat.ToString() + " cisel, muze byt max 6 !! ");
                        t[i].Checked = false;
                        PocZat = 6;
                    }
                    else
                    {
                        TipCis = TipCis + "   " + i.ToString();
                        Tip[PocZat] = i;
                    }
                }
            }
            tbTipovano.Text = TipCis;
            PocetZatrzenych = PocZat;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 50; i++)
            {
                t[i] = new CheckBox();
                t[i].Top = ((i - 1) % 12) * 20 + 20;    // % je operace modulo
                if (i < 13) t[i].Left = 20;
                else if (i < 25) t[i].Left = 70;
                else if (i < 37) t[i].Left = 120;
                else t[i].Left = 170;
                t[i].Width = 40;
                t[i].Text = i.ToString();
                Controls.Add(t[i]);
                                        // ZAREGISTRUJEME UDÁLOST
                t[i].CheckedChanged += new System.EventHandler(this.cBox_CheckedChanged);   // def bude pozdeji
            }         
            t[49] = new CheckBox();
            t[49].Top = 12 * 20 + 20;
            t[49].Left = 170;
            t[49].Width = 40;
            t[49].Text = "49";
            Controls.Add(t[49]);
            t[49].CheckedChanged += new System.EventHandler(this.cBox_CheckedChanged);    
        }

        static int pp = 0;                      // počet pokusů

        private void button1_Click(object sender, EventArgs e)
        {
            string TazCis = "";
            bool nove;

            if (PocetZatrzenych != 6) 
            {
                MessageBox.Show("Nemáte zetrženo 6 čísel!");
                return;
            }

            timer1.Enabled = true;
            
            Random G = new Random();
            int gc;
            for (int i = 1; i < 8; i++)
            {
                do
                {
                    gc = G.Next(49) + 1;
                    nove = true;                    // potrebujeme 7 ruznych cisel
                    for (int j = 1; j < i; j++)
                        if (Tazeno[j] == gc)
                        { nove = false; 
                            break; }
                } while (!nove);
                Tazeno[i] = gc;
            }
            tBDoplnkove.Text = Tazeno[7].ToString();                                
            for(int i=1;i<7;i++)
                TazCis=TazCis+"     "+Tazeno[i].ToString();
            tbTazeno.Text=TazCis;
            pp++;
            tBPocetPokusu.Text = pp.ToString();
            button2_Click(sender,e);            // OPERACE JAKO PO STISKU TLACITKA button2
        }

        static int pocetzasahu;

        private void button2_Click(object sender, EventArgs e)
        {
                                               // porovnavame prvky z obou poli Tazeno a Tip
            pocetzasahu = 0;

            if (PocetZatrzenych != 6)
            {
                MessageBox.Show("Nemáte zetrženo 6 čísel!");
                return;
            }

            string Uhodnuto = "";
            for (int i = 1; i < 7; i++)
                for (int j = 1; j < 7; j++)
                    if (Tazeno[i] == Tip[j])
                    {            
                        Uhodnuto = Uhodnuto + "    " + Tazeno[i].ToString();
                        pocetzasahu++;
                    }
            tbUhodnuto.Text = Uhodnuto;
                                    // hledáme pořadí výhry
            if(pocetzasahu < 3)
                tBVyhraPoradi.Text = "Nevyhrál jste!";
            if (pocetzasahu == 6)
                tBVyhraPoradi.Text = "1.";
            else if (pocetzasahu == 4)
                tBVyhraPoradi.Text = "4.";
            else if (pocetzasahu == 3)
                tBVyhraPoradi.Text = "5.";
            else if (pocetzasahu == 5)
                {
                    tBVyhraPoradi.Text = "3.";          // 5 zasahu bez doplnkoveho cisla je 3.poradi
                    for(int i=0; i<7; i++)
                        if (Tip[i] == Tazeno[7])        // když máme i doplnkove cislo, tak je to 2.poradi
                            tBVyhraPoradi.Text = "2.";
                }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button1_Click(sender, e);    // pokud jsem chytil 3 a více cisel tak je vyhra
            if (pocetzasahu > 2)         // pokud je nejaka vyhra, tak zastavime timer a ukazeme vysledky
            {
                timer1.Enabled = false;
                pp = 0;
            }
        }
    }
}
