﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.tbTipovano = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTazeno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tbUhodnuto = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBDoplnkove = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tBVyhraPoradi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tBPocetPokusu = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(309, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(257, 49);
            this.button1.TabIndex = 0;
            this.button1.Text = "Generování tahu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbTipovano
            // 
            this.tbTipovano.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbTipovano.Location = new System.Drawing.Point(309, 60);
            this.tbTipovano.Name = "tbTipovano";
            this.tbTipovano.Size = new System.Drawing.Size(257, 26);
            this.tbTipovano.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(305, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tipovaná čísla";
            // 
            // tbTazeno
            // 
            this.tbTazeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbTazeno.Location = new System.Drawing.Point(309, 183);
            this.tbTazeno.Name = "tbTazeno";
            this.tbTazeno.Size = new System.Drawing.Size(257, 26);
            this.tbTazeno.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(305, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tažená čísla";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(309, 268);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(257, 49);
            this.button2.TabIndex = 5;
            this.button2.Text = "Vyhodnocení tahu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbUhodnuto
            // 
            this.tbUhodnuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbUhodnuto.Location = new System.Drawing.Point(309, 328);
            this.tbUhodnuto.Name = "tbUhodnuto";
            this.tbUhodnuto.Size = new System.Drawing.Size(257, 26);
            this.tbUhodnuto.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(309, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Doplňkové číslo:";
            // 
            // tBDoplnkove
            // 
            this.tBDoplnkove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBDoplnkove.Location = new System.Drawing.Point(443, 231);
            this.tBDoplnkove.Name = "tBDoplnkove";
            this.tBDoplnkove.Size = new System.Drawing.Size(76, 26);
            this.tBDoplnkove.TabIndex = 8;
            this.tBDoplnkove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(306, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Výhra v pořadí::";
            // 
            // tBVyhraPoradi
            // 
            this.tBVyhraPoradi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBVyhraPoradi.Location = new System.Drawing.Point(423, 361);
            this.tBVyhraPoradi.Name = "tBVyhraPoradi";
            this.tBVyhraPoradi.Size = new System.Drawing.Size(143, 26);
            this.tBVyhraPoradi.TabIndex = 10;
            this.tBVyhraPoradi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 342);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Počet generování náhody:";
            // 
            // tBPocetPokusu
            // 
            this.tBPocetPokusu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBPocetPokusu.Location = new System.Drawing.Point(159, 334);
            this.tBPocetPokusu.Name = "tBPocetPokusu";
            this.tBPocetPokusu.Size = new System.Drawing.Size(76, 26);
            this.tBPocetPokusu.TabIndex = 12;
            this.tBPocetPokusu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer1
            // 
            this.timer1.Interval = 125;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 411);
            this.Controls.Add(this.tBPocetPokusu);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tBVyhraPoradi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tBDoplnkove);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbUhodnuto);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbTazeno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbTipovano);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Vyhodnoceni sportky";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbTipovano;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbTazeno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbUhodnuto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBDoplnkove;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBVyhraPoradi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tBPocetPokusu;
        private System.Windows.Forms.Timer timer1;
    }
}

