﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;             // kvuli operaci modulo pridano
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        CheckBox[] t = new CheckBox[50];            // vytvorime v pameti pole checkboxu
        int[] Tazeno = new int[8];                  // funkcni indexy 1 - 6, 7 je doplňkové
        int[] Tip = new int[7];

        private void cBox_CheckedChanged(object sender, System.EventArgs e)
        {
            int PocZat = 0;
            string TipCis = "";
            for (int i = 1; i < 50; i++)
            {
                if (t[i].Checked)
                {
                    PocZat++;
                    if (PocZat > 6)
                    {
                        MessageBox.Show("Mate zatrzeno:" + PocZat.ToString() + " cisel, muze byt max 6 !! ");
                        t[i].Checked = false;
                        PocZat = 6;
                    }
                    else
                    {
                        TipCis = TipCis + "   " + i.ToString();
                        Tip[PocZat] = i;
                    }
                }
            }
            tbTipovano.Text = TipCis;
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < 49; i++)
            {
                t[i] = new CheckBox();
                t[i].Top = (int)SqlInt32.Mod(i - 1, 12) * 20 + 20;
                if (i < 13) t[i].Left = 20;
                else if (i < 25) t[i].Left = 70;
                else if (i < 37) t[i].Left = 120;
                else t[i].Left = 170;
                t[i].Width = 40;
                t[i].Text = i.ToString();
                Controls.Add(t[i]); // přidáme checkbox na formulář, určíme funkci co obslouží událost
                t[i].CheckedChanged += new System.EventHandler(this.cBox_CheckedChanged);
            }         
            t[49] = new CheckBox();
            t[49].Top = 12 * 20 + 20;
            t[49].Left = 170;
            t[49].Width = 40;
            t[49].Text = "49";
            Controls.Add(t[49]);
            t[49].CheckedChanged += new System.EventHandler(this.cBox_CheckedChanged);    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string TazCis = "";
            bool nove;
            
            Random G = new Random();
            int gc;
            for (int i = 1; i < 8; i++)     // generujeme 7 různých hodnot tahu
            {
                do
                {
                    gc = G.Next(49) + 1;
                    nove = true;
                    for (int j = 1; j < i; j++)
                        if (Tazeno[j] == gc)
                        { nove = false; 
                            break; }
                } while (!nove);
                Tazeno[i] = gc;
            }
            tBDoplnkove.Text = Tazeno[7].ToString();
    
            for(int i=1;i<7;i++)
                TazCis=TazCis+"     "+Tazeno[i].ToString();
            tbTazeno.Text=TazCis;
          //  pp++;
            
            button2_Click(sender,e);
        }
        static int pocetzasahu;
        private void button2_Click(object sender, EventArgs e)
        {
                                          // porovnavame postupne prvky z obou poli Tazeno a Tip
            pocetzasahu = 0;
            string Uhodnuto = "";
            for (int i = 1; i < 7; i++)
                for (int j = 1; j < 7; j++)
                    if (Tazeno[i] == Tip[j])
                    {            
                        Uhodnuto = Uhodnuto + "    " + Tazeno[i].ToString();
                        pocetzasahu++;
                    }
            tbUhodnuto.Text = Uhodnuto;
                                    // hledáme pořadí výhry
            if(pocetzasahu < 3)
                tBVyhraPoradi.Text = "Nevyhrál jste!";
            if (pocetzasahu == 6)
                tBVyhraPoradi.Text = "1.";
            else if (pocetzasahu == 4)
                tBVyhraPoradi.Text = "4.";
            else if (pocetzasahu == 3)
                tBVyhraPoradi.Text = "5.";
            else if (pocetzasahu == 5)
                {
                    tBVyhraPoradi.Text = "3.";
                    for(int i=0; i<7; i++)
                        if (Tip[i] == Tazeno[7])
                            tBVyhraPoradi.Text = "2.";
                }
        }

        
    }
}
