﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FormHudebniny
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Form2 InstanceForm2 = new Form2();

        private void button1_Click(object sender, EventArgs e)
        {
            int kusu, cena1ks=0, cenacelkova;
            if (radioButton1.Checked)
                TBvybrZbozi.Text = radioButton1.Text;
            if (radioButton2.Checked)
                TBvybrZbozi.Text = radioButton2.Text;
            if (radioButton3.Checked)
                TBvybrZbozi.Text = radioButton3.Text;
            if (radioButton4.Checked)
                TBvybrZbozi.Text = radioButton4.Text;
            if (radioButton8.Checked)
                TBvybrZbozi.Text += " " + radioButton8.Text;
            if (radioButton7.Checked)
                TBvybrZbozi.Text += " " + radioButton7.Text;
            if (radioButton6.Checked)
                TBvybrZbozi.Text += " " + radioButton6.Text;
            if (radioButton5.Checked)
                TBvybrZbozi.Text += " " + radioButton5.Text;
            kusu = hScrollBar1.Value/10+1;
            TBvybrZbozi.Text += " " + kusu.ToString()+" ks";

            if (radioButton1.Checked)
            {
                if (radioButton8.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb11.Text);
                if (radioButton7.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb12.Text);
                if (radioButton6.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb13.Text);
                if (radioButton5.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb14.Text);
            }
            if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb21.Text);
                if (radioButton7.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb22.Text);
                if (radioButton6.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb23.Text);
                if (radioButton5.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb24.Text);
            }
            if (radioButton3.Checked)
            {
                if (radioButton8.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb31.Text);
                if (radioButton7.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb32.Text);
                if (radioButton6.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb33.Text);
                if (radioButton5.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb34.Text);
            }
            if (radioButton4.Checked)
            {
                if (radioButton8.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb41.Text);
                if (radioButton7.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb42.Text);
                if (radioButton6.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb43.Text);
                if (radioButton5.Checked)
                    cena1ks = Convert.ToInt32(InstanceForm2.tb44.Text);
            }   
            cenacelkova = cena1ks * kusu;
            TBcena.Text = cenacelkova.ToString() + " Kč";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InstanceForm2.Owner = this;
            InstanceForm2.Show();
        }
    }
}
