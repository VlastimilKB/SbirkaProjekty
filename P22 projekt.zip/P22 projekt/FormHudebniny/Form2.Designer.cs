﻿namespace FormHudebniny
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb11 = new System.Windows.Forms.TextBox();
            this.tb21 = new System.Windows.Forms.TextBox();
            this.tb41 = new System.Windows.Forms.TextBox();
            this.tb31 = new System.Windows.Forms.TextBox();
            this.tb42 = new System.Windows.Forms.TextBox();
            this.tb32 = new System.Windows.Forms.TextBox();
            this.tb22 = new System.Windows.Forms.TextBox();
            this.tb12 = new System.Windows.Forms.TextBox();
            this.tb43 = new System.Windows.Forms.TextBox();
            this.tb33 = new System.Windows.Forms.TextBox();
            this.tb23 = new System.Windows.Forms.TextBox();
            this.tb13 = new System.Windows.Forms.TextBox();
            this.tb44 = new System.Windows.Forms.TextBox();
            this.tb34 = new System.Windows.Forms.TextBox();
            this.tb24 = new System.Windows.Forms.TextBox();
            this.tb14 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(186, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "cena za 1 kus";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(57, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Abba";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(54, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lucie";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(54, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Olympic";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(54, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "U2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(155, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(309, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "CD         DVD       KAZETA    BLUE-RAY";
            // 
            // tb11
            // 
            this.tb11.Location = new System.Drawing.Point(136, 89);
            this.tb11.Name = "tb11";
            this.tb11.Size = new System.Drawing.Size(64, 20);
            this.tb11.TabIndex = 6;
            this.tb11.Text = "199";
            this.tb11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb21
            // 
            this.tb21.Location = new System.Drawing.Point(136, 125);
            this.tb21.Name = "tb21";
            this.tb21.Size = new System.Drawing.Size(64, 20);
            this.tb21.TabIndex = 7;
            this.tb21.Text = "179";
            this.tb21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41
            // 
            this.tb41.Location = new System.Drawing.Point(136, 201);
            this.tb41.Name = "tb41";
            this.tb41.Size = new System.Drawing.Size(64, 20);
            this.tb41.TabIndex = 9;
            this.tb41.Text = "569";
            this.tb41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31
            // 
            this.tb31.Location = new System.Drawing.Point(136, 165);
            this.tb31.Name = "tb31";
            this.tb31.Size = new System.Drawing.Size(64, 20);
            this.tb31.TabIndex = 8;
            this.tb31.Text = "209";
            this.tb31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42
            // 
            this.tb42.Location = new System.Drawing.Point(217, 201);
            this.tb42.Name = "tb42";
            this.tb42.Size = new System.Drawing.Size(64, 20);
            this.tb42.TabIndex = 13;
            this.tb42.Text = "899";
            this.tb42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32
            // 
            this.tb32.Location = new System.Drawing.Point(217, 165);
            this.tb32.Name = "tb32";
            this.tb32.Size = new System.Drawing.Size(64, 20);
            this.tb32.TabIndex = 12;
            this.tb32.Text = "459";
            this.tb32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb22
            // 
            this.tb22.Location = new System.Drawing.Point(217, 125);
            this.tb22.Name = "tb22";
            this.tb22.Size = new System.Drawing.Size(64, 20);
            this.tb22.TabIndex = 11;
            this.tb22.Text = "430";
            this.tb22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb12
            // 
            this.tb12.Location = new System.Drawing.Point(217, 89);
            this.tb12.Name = "tb12";
            this.tb12.Size = new System.Drawing.Size(64, 20);
            this.tb12.TabIndex = 10;
            this.tb12.Text = "395";
            this.tb12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43
            // 
            this.tb43.Location = new System.Drawing.Point(297, 202);
            this.tb43.Name = "tb43";
            this.tb43.Size = new System.Drawing.Size(64, 20);
            this.tb43.TabIndex = 17;
            this.tb43.Text = "279";
            this.tb43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33
            // 
            this.tb33.Location = new System.Drawing.Point(297, 166);
            this.tb33.Name = "tb33";
            this.tb33.Size = new System.Drawing.Size(64, 20);
            this.tb33.TabIndex = 16;
            this.tb33.Text = "139";
            this.tb33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb23
            // 
            this.tb23.Location = new System.Drawing.Point(297, 126);
            this.tb23.Name = "tb23";
            this.tb23.Size = new System.Drawing.Size(64, 20);
            this.tb23.TabIndex = 15;
            this.tb23.Text = "99";
            this.tb23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb13
            // 
            this.tb13.Location = new System.Drawing.Point(297, 90);
            this.tb13.Name = "tb13";
            this.tb13.Size = new System.Drawing.Size(64, 20);
            this.tb13.TabIndex = 14;
            this.tb13.Text = "119";
            this.tb13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44
            // 
            this.tb44.Location = new System.Drawing.Point(379, 202);
            this.tb44.Name = "tb44";
            this.tb44.Size = new System.Drawing.Size(64, 20);
            this.tb44.TabIndex = 21;
            this.tb44.Text = "965";
            this.tb44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34
            // 
            this.tb34.Location = new System.Drawing.Point(379, 166);
            this.tb34.Name = "tb34";
            this.tb34.Size = new System.Drawing.Size(64, 20);
            this.tb34.TabIndex = 20;
            this.tb34.Text = "529";
            this.tb34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb24
            // 
            this.tb24.Location = new System.Drawing.Point(379, 126);
            this.tb24.Name = "tb24";
            this.tb24.Size = new System.Drawing.Size(64, 20);
            this.tb24.TabIndex = 19;
            this.tb24.Text = "569";
            this.tb24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb14
            // 
            this.tb14.Location = new System.Drawing.Point(379, 90);
            this.tb14.Name = "tb14";
            this.tb14.Size = new System.Drawing.Size(64, 20);
            this.tb14.TabIndex = 18;
            this.tb14.Text = "695";
            this.tb14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(336, 243);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 28);
            this.button1.TabIndex = 22;
            this.button1.Text = "ZAVŘIT ...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 295);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb44);
            this.Controls.Add(this.tb34);
            this.Controls.Add(this.tb24);
            this.Controls.Add(this.tb14);
            this.Controls.Add(this.tb43);
            this.Controls.Add(this.tb33);
            this.Controls.Add(this.tb23);
            this.Controls.Add(this.tb13);
            this.Controls.Add(this.tb42);
            this.Controls.Add(this.tb32);
            this.Controls.Add(this.tb22);
            this.Controls.Add(this.tb12);
            this.Controls.Add(this.tb41);
            this.Controls.Add(this.tb31);
            this.Controls.Add(this.tb21);
            this.Controls.Add(this.tb11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Nabidka zbozi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox tb11;
        public System.Windows.Forms.TextBox tb21;
        public System.Windows.Forms.TextBox tb41;
        public System.Windows.Forms.TextBox tb31;
        public System.Windows.Forms.TextBox tb42;
        public System.Windows.Forms.TextBox tb32;
        public System.Windows.Forms.TextBox tb22;
        public System.Windows.Forms.TextBox tb12;
        public System.Windows.Forms.TextBox tb43;
        public System.Windows.Forms.TextBox tb33;
        public System.Windows.Forms.TextBox tb23;
        public System.Windows.Forms.TextBox tb13;
        public System.Windows.Forms.TextBox tb44;
        public System.Windows.Forms.TextBox tb34;
        public System.Windows.Forms.TextBox tb24;
        public System.Windows.Forms.TextBox tb14;
        private System.Windows.Forms.Button button1;
    }
}