﻿using System;

namespace ConsoleKvadratRovnice
{
    class Program
    {
        static int a, b, c, D;    // globalni promenne plati v cele tride

        static void VstupZadaniKR()
        {
            Console.Write("Zadejte koeficient A:");
            a=Convert.ToInt16(Console.ReadLine());
            Console.Write("Zadejte koeficient B:");
            b = Convert.ToInt16(Console.ReadLine());
            Console.Write("Zadejte koeficient C:");
            c = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Mate zadanou rovnici: "+a+" X na 2 + "+b+" X + "+c);
        }

        static int VypoctiD()
        {
            int d;
            d = b * b - 4 * a * c;
            Console.WriteLine("D = "+d);
            if (d > 0)
                Console.WriteLine("Dva realne ruzne koreny");
            else if (d == 0)
                Console.WriteLine("Dvojnasobny realny koren");
            else
                Console.WriteLine("Dva komplexne sdruzene koreny");
            return d;
        }

        static void Main(string[] args)
        {
            double x1, x2, xr, xi;
            VstupZadaniKR();
            D = VypoctiD();
            if (D > 0)
            {
                x1 = (-b + Math.Sqrt((double)D)) / 2 / a;
                x2 = (-b - Math.Sqrt((double)D)) / 2 / a;
                Console.WriteLine("Koreny: x1= " + x1.ToString("##0.###") + " x2= " + x2.ToString("##0.###"));
            }
            else if (D == 0)
                {
                    x1 = (-b) / 2.0 / a;
                    x2 = x1;
                    Console.WriteLine("Koreny: x1= " + x1.ToString("##0.###") + " x2= " + x2.ToString("##0.###"));
                }
            else
                {
                    xr = (-b) / 2.0 / a;
                    xi = (Math.Sqrt((double)-D)) / 2.0 / a;
                    Console.Write("Koreny: x1= "+xr.ToString("##0.###")+"+"+ xi.ToString("##0.###")+" i");
                    Console.WriteLine("  x2= "+xr.ToString("##0.###")+"-"+ xi.ToString("##0.###")+" i");    
                }
            Console.ReadLine();
        }
    }
}

