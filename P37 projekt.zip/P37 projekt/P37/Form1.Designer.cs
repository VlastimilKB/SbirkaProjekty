﻿namespace P37
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tBhodiny = new System.Windows.Forms.TextBox();
            this.tBminuty = new System.Windows.Forms.TextBox();
            this.tBsekundy = new System.Windows.Forms.TextBox();
            this.butUkazCas = new System.Windows.Forms.Button();
            this.tBden = new System.Windows.Forms.TextBox();
            this.tbMESIC = new System.Windows.Forms.TextBox();
            this.tBdentydne = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tBdvojtecka = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tBhodiny
            // 
            this.tBhodiny.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBhodiny.Location = new System.Drawing.Point(39, 36);
            this.tBhodiny.Name = "tBhodiny";
            this.tBhodiny.Size = new System.Drawing.Size(103, 80);
            this.tBhodiny.TabIndex = 0;
            this.tBhodiny.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBminuty
            // 
            this.tBminuty.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBminuty.Location = new System.Drawing.Point(170, 36);
            this.tBminuty.Name = "tBminuty";
            this.tBminuty.Size = new System.Drawing.Size(103, 80);
            this.tBminuty.TabIndex = 1;
            this.tBminuty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBsekundy
            // 
            this.tBsekundy.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBsekundy.Location = new System.Drawing.Point(309, 36);
            this.tBsekundy.Name = "tBsekundy";
            this.tBsekundy.Size = new System.Drawing.Size(103, 80);
            this.tBsekundy.TabIndex = 2;
            this.tBsekundy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // butUkazCas
            // 
            this.butUkazCas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.butUkazCas.Location = new System.Drawing.Point(464, 50);
            this.butUkazCas.Name = "butUkazCas";
            this.butUkazCas.Size = new System.Drawing.Size(96, 35);
            this.butUkazCas.TabIndex = 3;
            this.butUkazCas.Text = "Ukaž čas";
            this.butUkazCas.UseVisualStyleBackColor = true;
            this.butUkazCas.Click += new System.EventHandler(this.butUkazCas_Click);
            // 
            // tBden
            // 
            this.tBden.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBden.Location = new System.Drawing.Point(56, 164);
            this.tBden.Name = "tBden";
            this.tBden.Size = new System.Drawing.Size(63, 47);
            this.tBden.TabIndex = 4;
            this.tBden.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMESIC
            // 
            this.tbMESIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbMESIC.Location = new System.Drawing.Point(158, 164);
            this.tbMESIC.Name = "tbMESIC";
            this.tbMESIC.Size = new System.Drawing.Size(63, 47);
            this.tbMESIC.TabIndex = 5;
            this.tbMESIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBdentydne
            // 
            this.tBdentydne.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBdentydne.Location = new System.Drawing.Point(262, 164);
            this.tBdentydne.Name = "tBdentydne";
            this.tBdentydne.Size = new System.Drawing.Size(160, 47);
            this.tBdentydne.TabIndex = 6;
            this.tBdentydne.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "HODINY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "MINUTY";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "SEKUNDY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "DEN";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(167, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "MĚSÍC";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(306, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "DEN TÝDNE";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tBdvojtecka
            // 
            this.tBdvojtecka.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBdvojtecka.Location = new System.Drawing.Point(274, 36);
            this.tBdvojtecka.Name = "tBdvojtecka";
            this.tBdvojtecka.Size = new System.Drawing.Size(29, 80);
            this.tBdvojtecka.TabIndex = 13;
            this.tBdvojtecka.Text = ":";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 248);
            this.Controls.Add(this.tBdvojtecka);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tBdentydne);
            this.Controls.Add(this.tbMESIC);
            this.Controls.Add(this.tBden);
            this.Controls.Add(this.butUkazCas);
            this.Controls.Add(this.tBsekundy);
            this.Controls.Add(this.tBminuty);
            this.Controls.Add(this.tBhodiny);
            this.Name = "Form1";
            this.Text = "hodiny v text boxu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tBhodiny;
        private System.Windows.Forms.TextBox tBminuty;
        private System.Windows.Forms.TextBox tBsekundy;
        private System.Windows.Forms.Button butUkazCas;
        private System.Windows.Forms.TextBox tBden;
        private System.Windows.Forms.TextBox tbMESIC;
        private System.Windows.Forms.TextBox tBdentydne;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox tBdvojtecka;
    }
}

