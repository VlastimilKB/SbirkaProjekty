﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace P37
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void butUkazCas_Click(object sender, EventArgs e)
        {
            DateTime Cas = new DateTime();
            Cas = DateTime.Now;         // precteme aktualni cas ze systému
            int hod, min, sek, den, mesic;
            string dentydne;
            hod = Cas.Hour;
            min = Cas.Minute;
            sek = Cas.Second;
            tBhodiny.Text = hod.ToString();
            tBminuty.Text = min.ToString();
            tBsekundy.Text = sek.ToString();
            den = Cas.Day;
            tBden.Text = den.ToString();
            mesic = Cas.Month;
            tbMESIC.Text = mesic.ToString();
            dentydne = Cas.DayOfWeek.ToString();
            tBdentydne.Text = dentydne;

            timer1.Enabled = true;         // spustime timer pro chod hodin

        }

        private void timer1_Tick(object sender, EventArgs e)
                            // akce se provede vzdy po 1000 milisekundach, viz parametr Interval 
        {
            DateTime Cas = new DateTime();
            Cas = DateTime.Now;
            int hod, min, sek;
            hod = Cas.Hour;
            min = Cas.Minute;
            sek = Cas.Second;
            if(hod>9)
                tBhodiny.Text = hod.ToString();
            else				  // vedouci nula pro mensi hodnoty 0-9
                tBhodiny.Text = "0"+hod.ToString();
            if (min > 9)
                tBminuty.Text = min.ToString();
            else
                tBminuty.Text = "0"+min.ToString();
            if(sek>9)
                tBsekundy.Text = sek.ToString();
            else
                tBsekundy.Text = "0"+sek.ToString();
            if (tBdvojtecka.Text == ":")                
                                                    // blikani dvojtecky
                tBdvojtecka.Text = "";
            else
                tBdvojtecka.Text = ":";
        }

    }
}
