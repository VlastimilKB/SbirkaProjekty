﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vypocet();
        }

        private void vypocet()
        {
            double a, b, c, d, x1, x2, x1i, x2i;
            a = Convert.ToDouble(tbA.Text);
            b = Convert.ToDouble(tbB.Text);
            c = Convert.ToDouble(tbC.Text);
            d = b * b - 4 * a * c;
            tbDiskriminant.Text = d.ToString();
            tbX1I.Text = "";
            tbX2I.Text = "";
            if (d > 0)
            {
                x1 = (-b + Math.Sqrt(d)) / 2 / a;
                x2 = (-b - Math.Sqrt(d)) / 2 / a;
                tbX1R.Text = String.Format("{0:0.00}", x1);
                tbX2R.Text = String.Format("{0:0.00}", x2);
            }
            else if (d < 0)
            {
                x1 = -b / 2 / a;                // realna cast
                x2 = x1;
                tbX1R.Text = String.Format("{0:0.00}", x1);
                tbX2R.Text = String.Format("{0:0.00}", x2);
                x1i = Math.Sqrt(-d) / 2 / a;    // imagin cast
                x2i = x1i;
                tbX1I.Text = String.Format("{0:0.00}", x1i) + " i";
                tbX2I.Text = String.Format("{0:0.00}", x2i) + " i";
                // labelMinus.Text = "-";
            }
            else
            {
                x1 = (-b) / 2 / a;
                x2 = (-b) / 2 / a;
                tbX1R.Text = String.Format("{0:0.00}", x1);
                tbX2R.Text = String.Format("{0:0.00}", x2);
            }
        }

        private void tbA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)           // reakce pouze na Enter 13 je 0D hexa
            {
                vypocet();
            }
        }

        private void tbB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)           // reakce pouze na Enter
            {
                vypocet();
            }
        }

        private void tbC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)           // reakce pouze na Enter
            {
                vypocet();
            }
        }
    }
}
