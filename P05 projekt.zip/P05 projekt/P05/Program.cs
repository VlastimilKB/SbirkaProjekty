﻿using System;

namespace VyctovyTyp
{
    class Program
    {
        enum DnyVTydnu { Pon = 1, Ute, Str, Ctv, Pat, Sob, Ned };
        enum VolneDny { Sob, Ned };
        static void Main(string[] args)
        {
            // cyklus foreach postupně použije všechny prvky kolekce nebo 
            // pole hodnot
            foreach (DnyVTydnu val in Enum.GetValues(typeof(DnyVTydnu)))
            {
                Console.WriteLine(val);
            }
            Console.ReadLine();
            foreach (VolneDny val in Enum.GetValues(typeof(VolneDny)))
            {
                Console.WriteLine(val);
            }
            Console.ReadLine();
        }
    }
}

