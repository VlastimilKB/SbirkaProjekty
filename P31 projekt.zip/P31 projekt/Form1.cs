﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinGrafikaPostup
{
    public partial class Form1 : Form
    {
        private Bitmap KresliciOblast;      // doplněno
        private Pen mojeTuzka;              // doplněno

        // vybrat událost Paint na Form1, dojde k doplnění události do projektu viz Form1.Designer.cs 
        // this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);

        public Form1()
        {
            InitializeComponent();
        }

        private void InicKresliciOblasti()  // doplněná funkce
        {
            Graphics Pozadi;
            mojeTuzka = new Pen(Color.White);            // bledě modrá barva pozadí
            Pozadi = Graphics.FromImage(KresliciOblast);
            for (int x = 0; x < this.Width; x++)        // postupně si vyčárujeme pozadí 
                Pozadi.DrawLine(mojeTuzka, x, 0, x, this.Height);
            Pozadi.Dispose();
            this.Invalidate();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int sirka=this.ClientRectangle.Width;
            int vyska=this.ClientRectangle.Height;
            KresliciOblast = new Bitmap(sirka,vyska,System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            InicKresliciOblasti();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics Kresba;
            Kresba = e.Graphics;
            Kresba.DrawImage(KresliciOblast,0,0,KresliciOblast.Width,KresliciOblast.Height);
        }

        private void Ctverecek(int levy, int horni, int hrana, int barva)// 1 - černá, -1 - bílá
        {
            Graphics Kresba;
            Kresba = Graphics.FromImage(KresliciOblast); // až teď můžeme začít kreslit po formuláři

            Random G=new Random();
            if(barva>0)
                mojeTuzka.Color = Color.Black;
            else
                mojeTuzka.Color = Color.White;

            for (int x = 0; x < hrana; x++ )
                Kresba.DrawLine(mojeTuzka, levy, horni+x, levy+hrana, horni+x);
            
            Kresba.Dispose();       // uvolníme paměť
            this.Invalidate();      // překreslíme formulář, změna zobrazení vstoupí v platnost
        }

        private void button1_Click(object sender, EventArgs e)  
        {
            Ctverecek(100,100,50,1);
            Ctverecek(150,100,50,-1);
        }
        
        int barva = -1;     // přepínač pro nastavení barev černá nebo bílá

        private void button2_Click_1(object sender, EventArgs e)    // kreslime šachovnici
        {
            for(int x=50; x<401; x+=50)
            {   barva = barva * (-1);
                for (int y = 50; y < 401; y += 50)
                    {
                        barva = barva * (-1);
                        Ctverecek(x, y, 50, barva);
                    }
             }
                                // popisy a,b,c,...,h a čísla 1 - 8
            Graphics Kresba;
            Kresba = Graphics.FromImage(KresliciOblast);
            Font drawfont = new Font("Arial", 10);
            Brush blackBrush = new SolidBrush(Color.DarkBlue);
            for (int i = 0; i < 8; i++)
            {                   // ASCII kódy číslic 1 - 8 tedy hodnoty 49 - 56
                Kresba.DrawString(((char)(49 + i)).ToString(), drawfont, blackBrush, 23, 412 - i * 50);
                                // ASCII kódy písmen: pocinaje od A=65 
                Kresba.DrawString(((char)(65 + i)).ToString(), drawfont, blackBrush, 71 + i * 50, 460);
            }
                // orámování šachovnice
            mojeTuzka.Color = Color.Black;
            Kresba.DrawLine(mojeTuzka, 49, 49, 49, 401);        // levá svisle
            Kresba.DrawLine(mojeTuzka, 451, 49, 451, 451);      // pravá svisle
            Kresba.DrawLine(mojeTuzka, 49, 49, 451, 49);        // horní
            Kresba.DrawLine(mojeTuzka, 49, 450, 451, 450);      // spodní
        } 

        private void button4_Click(object sender, EventArgs e)
        {
            InicKresliciOblasti();
        }
        
        private void button2_Click(object sender, EventArgs e)      // 3 x button odstraneno po odladeni
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {    
        }

        private void button5_Click(object sender, EventArgs e)
        {
        }

       
    }
}
