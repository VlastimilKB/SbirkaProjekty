﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)  // součet
        {
            komplexne_cislo A = new komplexne_cislo(0,0);
            komplexne_cislo B = new komplexne_cislo(0,0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR,pomI);
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            B.nastav_hodnotu(pomR, pomI);
            V = A + B;      // voláme přetížený operátor + pro součet dvou komp čísel
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? V.rc().ToString("0#.##") : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? V.ic().ToString("0#.##") : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ? V.hR().ToString("0#.##") : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? V.hFi().ToString("0#.##") : V.hFi().ToString("#.##");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)      // rozdíl
        {
            komplexne_cislo A = new komplexne_cislo(0, 0);
            komplexne_cislo B = new komplexne_cislo(0, 0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR, pomI);
            // MessageBox.Show("Máme nastaveno A: "+A.rc()+" + "+A.ic()+" i");
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            B.nastav_hodnotu(pomR, pomI);
            // MessageBox.Show("Máme nastaveno A: " + B.rc() + " + " + B.ic() + " i");
            V = A - B;
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? V.rc().ToString("0#.##") : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? V.ic().ToString("0#.##") : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ? V.hR().ToString("0#.##") : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? V.hFi().ToString("0#.##") : V.hFi().ToString("#.##");
        }

        private void button3_Click(object sender, EventArgs e)      // soucin
        {
            komplexne_cislo A = new komplexne_cislo(0, 0);
            komplexne_cislo B = new komplexne_cislo(0, 0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR, pomI);
            // MessageBox.Show("Máme nastaveno A: "+A.rc()+" + "+A.ic()+" i");
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            B.nastav_hodnotu(pomR, pomI);
            // MessageBox.Show("Máme nastaveno A: " + B.rc() + " + " + B.ic() + " i");
            V = A * B;
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? V.rc().ToString("0#.##") : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? V.ic().ToString("0#.##") : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ? V.hR().ToString("0#.##") : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? V.hFi().ToString("0#.##") : V.hFi().ToString("#.##");
        }

        private void button4_Click(object sender, EventArgs e)          // podil
        {
            komplexne_cislo A = new komplexne_cislo(0, 0);
            komplexne_cislo B = new komplexne_cislo(0, 0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR, pomI);
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            B.nastav_hodnotu(pomR, pomI);
            V = A / B;
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? V.rc().ToString("0#.##") : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? V.ic().ToString("0#.##") : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ? V.hR().ToString("0#.##") : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? V.hFi().ToString("0#.##") : V.hFi().ToString("#.##");    
        }

    }

    class komplexne_cislo
    {
        private double realna_cast, imag_cast;
        private double R, Fi;

        public void UdelejPolSouradnice()
        {
            R = Math.Sqrt(realna_cast * realna_cast + imag_cast * imag_cast);
            Fi = 180 * Math.Atan2(imag_cast, realna_cast) / Math.PI;        // PŘEVOD NA STUPNĚ 180 * H / Pi
        }               // arcus tangens podílu ima  re částí

        public double hR()
        {
            return R;
        }

        public double hFi()
        {
            return Fi;
        }

        public komplexne_cislo(double R, double I)  // konstruktor 1
        {
            realna_cast = R;
            imag_cast = I;
        }

        public komplexne_cislo(double R)            // konstruktor 2
        {
            realna_cast = R;
            imag_cast = 0;
        }

        public komplexne_cislo(int I)               // konstruktor 3
        {
            realna_cast = 0;
            imag_cast = I;
        }

        public static komplexne_cislo operator +(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(c1.realna_cast + c2.realna_cast, c1.imag_cast + c2.imag_cast);
        }

        public static komplexne_cislo operator -(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(c1.realna_cast - c2.realna_cast, c1.imag_cast - c2.imag_cast);
        }

        public static komplexne_cislo operator *(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo((c1.realna_cast * c2.realna_cast) - (c1.imag_cast * c2.imag_cast), c1.realna_cast * c2.imag_cast + c2.realna_cast * c1.imag_cast);
        }

        public static komplexne_cislo operator /(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(((c1.realna_cast * c2.realna_cast) + (c1.imag_cast * c2.imag_cast)) / (c2.realna_cast * c2.realna_cast + c2.imag_cast * c2.imag_cast),
               (c1.imag_cast * c2.realna_cast - c1.realna_cast * c2.imag_cast) / (c2.realna_cast * c2.realna_cast + c2.imag_cast * c2.imag_cast));
        }

        public double rc()
        {
            return realna_cast;
        }

        public double ic()
        {
            return imag_cast;
        }

        public double Modul()
        {
            double vysledek;
            vysledek = Math.Sqrt(realna_cast * realna_cast + imag_cast * imag_cast);
            return vysledek;
        }

        public void nastav_hodnotu(double x, double y)
        {
            realna_cast = x;
            imag_cast = y;
        }
    }           // konec definice třídy

}
