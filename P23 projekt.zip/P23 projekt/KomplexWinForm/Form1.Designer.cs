﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbAReal = new System.Windows.Forms.TextBox();
            this.tbBReal = new System.Windows.Forms.TextBox();
            this.tbAImag = new System.Windows.Forms.TextBox();
            this.tbBImag = new System.Windows.Forms.TextBox();
            this.tbVReal = new System.Windows.Forms.TextBox();
            this.tbVImag = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbR = new System.Windows.Forms.TextBox();
            this.tbFi = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "komplexní číslo A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(12, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "komplexní číslo B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(16, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "komplexní číslo V";
            // 
            // tbAReal
            // 
            this.tbAReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbAReal.Location = new System.Drawing.Point(141, 35);
            this.tbAReal.Name = "tbAReal";
            this.tbAReal.Size = new System.Drawing.Size(98, 29);
            this.tbAReal.TabIndex = 3;
            this.tbAReal.Text = "0";
            this.tbAReal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBReal
            // 
            this.tbBReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbBReal.Location = new System.Drawing.Point(141, 77);
            this.tbBReal.Name = "tbBReal";
            this.tbBReal.Size = new System.Drawing.Size(98, 29);
            this.tbBReal.TabIndex = 4;
            this.tbBReal.Text = "0";
            this.tbBReal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAImag
            // 
            this.tbAImag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbAImag.Location = new System.Drawing.Point(256, 35);
            this.tbAImag.Name = "tbAImag";
            this.tbAImag.Size = new System.Drawing.Size(98, 29);
            this.tbAImag.TabIndex = 5;
            this.tbAImag.Text = "0";
            this.tbAImag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBImag
            // 
            this.tbBImag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbBImag.Location = new System.Drawing.Point(256, 77);
            this.tbBImag.Name = "tbBImag";
            this.tbBImag.Size = new System.Drawing.Size(98, 29);
            this.tbBImag.TabIndex = 6;
            this.tbBImag.Text = "0";
            this.tbBImag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbVReal
            // 
            this.tbVReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbVReal.Location = new System.Drawing.Point(141, 144);
            this.tbVReal.Name = "tbVReal";
            this.tbVReal.Size = new System.Drawing.Size(98, 29);
            this.tbVReal.TabIndex = 7;
            this.tbVReal.Text = "0";
            this.tbVReal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbVImag
            // 
            this.tbVImag.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbVImag.Location = new System.Drawing.Point(256, 144);
            this.tbVImag.Name = "tbVImag";
            this.tbVImag.Size = new System.Drawing.Size(98, 29);
            this.tbVImag.TabIndex = 8;
            this.tbVImag.Text = "0";
            this.tbVImag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(390, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 66);
            this.button1.TabIndex = 9;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(471, 35);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 66);
            this.button2.TabIndex = 10;
            this.button2.Text = "-";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(390, 111);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 66);
            this.button3.TabIndex = 11;
            this.button3.Text = "x";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.Location = new System.Drawing.Point(471, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 66);
            this.button4.TabIndex = 12;
            this.button4.Text = "/";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(93, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "R=";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(252, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Fi=";
            // 
            // tbR
            // 
            this.tbR.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbR.Location = new System.Drawing.Point(141, 196);
            this.tbR.Name = "tbR";
            this.tbR.Size = new System.Drawing.Size(98, 29);
            this.tbR.TabIndex = 15;
            this.tbR.Text = "0";
            this.tbR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFi
            // 
            this.tbFi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbFi.Location = new System.Drawing.Point(303, 196);
            this.tbFi.Name = "tbFi";
            this.tbFi.Size = new System.Drawing.Size(98, 29);
            this.tbFi.TabIndex = 16;
            this.tbFi.Text = "0";
            this.tbFi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 274);
            this.Controls.Add(this.tbFi);
            this.Controls.Add(this.tbR);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbVImag);
            this.Controls.Add(this.tbVReal);
            this.Controls.Add(this.tbBImag);
            this.Controls.Add(this.tbAImag);
            this.Controls.Add(this.tbBReal);
            this.Controls.Add(this.tbAReal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Práce s komplexními čísly";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbAReal;
        private System.Windows.Forms.TextBox tbBReal;
        private System.Windows.Forms.TextBox tbAImag;
        private System.Windows.Forms.TextBox tbBImag;
        private System.Windows.Forms.TextBox tbVReal;
        private System.Windows.Forms.TextBox tbVImag;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbR;
        private System.Windows.Forms.TextBox tbFi;
    }
}

