﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Vypocet(char operace)  // vypocet + - *
        {
            komplexne_cislo A = new komplexne_cislo(0, 0);
            komplexne_cislo B = new komplexne_cislo(0, 0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR, pomI);
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            B.nastav_hodnotu(pomR, pomI);
            switch(operace)
            {
                case '+': V = A + B; break;   // voláme přetížený operátor + pro součet dvou komp čísel
                case '-': V = A - B; break;   // voláme přetížený operátor - pro součet dvou komp čísel
                case '*': V = A * B; break;   // voláme přetížený operátor * pro součet dvou komp čísel
            }
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? V.rc().ToString("#.##") : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? V.ic().ToString("#.##") : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ? V.hR().ToString("#.##") : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? V.hFi().ToString("#.##") : V.hFi().ToString("#.##");

        } 

        private void button1_Click(object sender, EventArgs e)  // součet
        {
            Vypocet('+');
        }

        private void button2_Click(object sender, EventArgs e)      // rozdíl
        {
            Vypocet('-');
        }

        private void button3_Click(object sender, EventArgs e)      // soucin
        {
            Vypocet('*');
        }

        private string Oprava(string puvodne)       //  0-    na    -0
        {
            if (puvodne.Substring(0, 2) == "0-")
                return ("-0" + puvodne.Substring(2));
            else
                return puvodne;
        }

        private void button4_Click(object sender, EventArgs e)          // podil
        {
            komplexne_cislo A = new komplexne_cislo(0, 0);
            komplexne_cislo B = new komplexne_cislo(0, 0);
            komplexne_cislo V = new komplexne_cislo(0, 0);
            double pomR, pomI;
            pomR = Convert.ToSingle(tbAReal.Text);
            pomI = Convert.ToSingle(tbAImag.Text);
            A.nastav_hodnotu(pomR, pomI);
            pomR = Convert.ToSingle(tbBReal.Text);
            pomI = Convert.ToSingle(tbBImag.Text);
            if( pomR==0 && pomI==0 ){
                MessageBox.Show("Nelze dělit 0");
                return;
            }
            B.nastav_hodnotu(pomR, pomI);
            V = A / B;
            tbVReal.Text = Math.Abs(V.rc()) < 1 ? ("0" + V.rc().ToString("#.##")) : V.rc().ToString("#.##");
            tbVImag.Text = Math.Abs(V.ic()) < 1 ? ("0" + V.ic().ToString("#.##")) : V.ic().ToString("#.##");
            V.UdelejPolSouradnice();
            tbR.Text = Math.Abs(V.hR()) < 1 ?   ("0" + V.hR().ToString("#.##")) : V.hR().ToString("#.##");
            tbFi.Text = Math.Abs(V.hFi()) < 1 ? ("0" + V.hFi().ToString("#.##")) : V.hFi().ToString("#.##");
            tbVReal.Text = Oprava(tbVReal.Text);
            tbVImag.Text = Oprava(tbVImag.Text);
        }
    }

    class komplexne_cislo
    {
        private double realna_cast, imag_cast;
        private double R, Fi;

        public void UdelejPolSouradnice()
        {
            R = Math.Sqrt(realna_cast * realna_cast + imag_cast * imag_cast);
            Fi = 180 * Math.Atan2(imag_cast, realna_cast) / Math.PI;        // PŘEVOD NA STUPNĚ 180 * H / Pi
        }               // arcus tangens podílu ima  re částí

        public double hR()
        {
            return R;
        }

        public double hFi()
        {
            return Fi;
        }

        public komplexne_cislo(double R, double I)  // konstruktor 1
        {
            realna_cast = R;
            imag_cast = I;
        }

        public komplexne_cislo(double R)            // konstruktor 2
        {
            realna_cast = R;
            imag_cast = 0;
        }

        public komplexne_cislo(int I)               // konstruktor 3
        {
            realna_cast = 0;
            imag_cast = I;
        }

        public static komplexne_cislo operator +(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(c1.realna_cast + c2.realna_cast, c1.imag_cast + c2.imag_cast);
        }

        public static komplexne_cislo operator -(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(c1.realna_cast - c2.realna_cast, c1.imag_cast - c2.imag_cast);
        }

        public static komplexne_cislo operator *(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo((c1.realna_cast * c2.realna_cast) - (c1.imag_cast * c2.imag_cast), c1.realna_cast * c2.imag_cast + c2.realna_cast * c1.imag_cast);
        }

        public static komplexne_cislo operator /(komplexne_cislo c1, komplexne_cislo c2)
        {
            return new komplexne_cislo(((c1.realna_cast * c2.realna_cast) + (c1.imag_cast * c2.imag_cast)) / (c2.realna_cast * c2.realna_cast + c2.imag_cast * c2.imag_cast),
               (c1.imag_cast * c2.realna_cast - c1.realna_cast * c2.imag_cast) / (c2.realna_cast * c2.realna_cast + c2.imag_cast * c2.imag_cast));
        }

        public double rc()
        {
            return realna_cast;
        }

        public double ic()
        {
            return imag_cast;
        }

        public double Modul()
        {
            double vysledek;
            vysledek = Math.Sqrt(realna_cast * realna_cast + imag_cast * imag_cast);
            return vysledek;
        }

        public void nastav_hodnotu(double x, double y)
        {
            realna_cast = x;
            imag_cast = y;
        }
    }           // konec definice třídy

}
