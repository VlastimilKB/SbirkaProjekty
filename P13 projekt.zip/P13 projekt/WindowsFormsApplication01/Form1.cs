﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BToperaceplus_Click(object sender, EventArgs e)
        {
            float c1=0, c2=0, v;
            float cislo;

            if (float.TryParse(TBcislo1.Text, out cislo))
               c1 = cislo;     // TextBox obsahuje platné číslo
            else
               {
                   MessageBox.Show("Zadej platné číslo A!");
               }
            if (float.TryParse(TBcislo2.Text, out cislo))
               c2 = cislo;     // TextBox obsahuje platné číslo
            else
               {
                   MessageBox.Show("Zadej platné číslo B!");
               }
            v = c1 + c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "+";               // oprava labelu s operací
        }

        private void BToperaceminus_Click(object sender, EventArgs e)
        {
            float c1 = 0, c2 = 0, v;
            float cislo;

            if (float.TryParse(TBcislo1.Text, out cislo))
                c1 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo A!");
            }
            if (float.TryParse(TBcislo2.Text, out cislo))
                c2 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo B!");
            }
            v = c1 + c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "-";               // oprava labelu s operací 
        }

        private void BToperacekrat_Click(object sender, EventArgs e)
        {
            float c1 = 0, c2 = 0, v;
            float cislo;

            if (float.TryParse(TBcislo1.Text, out cislo))
                c1 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo A!");
            }
            if (float.TryParse(TBcislo2.Text, out cislo))
                c2 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo B!");
            }
            v = c1 + c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "x";
        }

        private void BToperacedeleno_Click(object sender, EventArgs e)
        {
            float c1 = 0, c2 = 0, v;
            float cislo;

            if (float.TryParse(TBcislo1.Text, out cislo))
                c1 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo A!");
            }
            if (float.TryParse(TBcislo2.Text, out cislo))
                c2 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo B!");
            }
            if (c2 != 0)				// musíme zabránit dělení 0
                v = c1 / c2;
            else
            {
                MessageBox.Show("Nelze dělit nulou");
                return;
            }
            TBvysledek.Text = v.ToString("0.000");
            LBoperace.Text = ":";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, v, c1=0, cislo;
            if (double.TryParse(TBcislo1.Text, out cislo))
                c1 = cislo;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo A!");
                return;
            }
            a = Convert.ToDouble(TBcislo1.Text);
            v = Math.Sin(a*Math.PI/180);
            TBvysledek.Text = v.ToString("0.###");
        }
    }
}
