﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TBcislo1 = new System.Windows.Forms.TextBox();
            this.TBcislo2 = new System.Windows.Forms.TextBox();
            this.LBoperace = new System.Windows.Forms.Label();
            this.TBvysledek = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BToperaceplus = new System.Windows.Forms.Button();
            this.BToperaceminus = new System.Windows.Forms.Button();
            this.BToperacekrat = new System.Windows.Forms.Button();
            this.BToperacedeleno = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TBcislo1
            // 
            this.TBcislo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.TBcislo1.Location = new System.Drawing.Point(13, 37);
            this.TBcislo1.Name = "TBcislo1";
            this.TBcislo1.Size = new System.Drawing.Size(84, 26);
            this.TBcislo1.TabIndex = 0;
            this.TBcislo1.Text = "0";
            this.TBcislo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TBcislo2
            // 
            this.TBcislo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.TBcislo2.Location = new System.Drawing.Point(169, 38);
            this.TBcislo2.Name = "TBcislo2";
            this.TBcislo2.Size = new System.Drawing.Size(79, 26);
            this.TBcislo2.TabIndex = 1;
            this.TBcislo2.Text = "0";
            this.TBcislo2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LBoperace
            // 
            this.LBoperace.AutoSize = true;
            this.LBoperace.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.LBoperace.Location = new System.Drawing.Point(125, 40);
            this.LBoperace.Name = "LBoperace";
            this.LBoperace.Size = new System.Drawing.Size(25, 25);
            this.LBoperace.TabIndex = 2;
            this.LBoperace.Text = "+";
            // 
            // TBvysledek
            // 
            this.TBvysledek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.TBvysledek.Location = new System.Drawing.Point(304, 40);
            this.TBvysledek.Name = "TBvysledek";
            this.TBvysledek.Size = new System.Drawing.Size(79, 26);
            this.TBvysledek.TabIndex = 3;
            this.TBvysledek.Text = "0";
            this.TBvysledek.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(266, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "=";
            // 
            // BToperaceplus
            // 
            this.BToperaceplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BToperaceplus.Location = new System.Drawing.Point(26, 90);
            this.BToperaceplus.Name = "BToperaceplus";
            this.BToperaceplus.Size = new System.Drawing.Size(47, 37);
            this.BToperaceplus.TabIndex = 5;
            this.BToperaceplus.Text = "+";
            this.BToperaceplus.UseVisualStyleBackColor = true;
            this.BToperaceplus.Click += new System.EventHandler(this.BToperaceplus_Click);
            // 
            // BToperaceminus
            // 
            this.BToperaceminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BToperaceminus.Location = new System.Drawing.Point(91, 90);
            this.BToperaceminus.Name = "BToperaceminus";
            this.BToperaceminus.Size = new System.Drawing.Size(47, 37);
            this.BToperaceminus.TabIndex = 6;
            this.BToperaceminus.Text = "-";
            this.BToperaceminus.UseVisualStyleBackColor = true;
            this.BToperaceminus.Click += new System.EventHandler(this.BToperaceminus_Click);
            // 
            // BToperacekrat
            // 
            this.BToperacekrat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BToperacekrat.Location = new System.Drawing.Point(160, 91);
            this.BToperacekrat.Name = "BToperacekrat";
            this.BToperacekrat.Size = new System.Drawing.Size(47, 37);
            this.BToperacekrat.TabIndex = 7;
            this.BToperacekrat.Text = "x";
            this.BToperacekrat.UseVisualStyleBackColor = true;
            this.BToperacekrat.Click += new System.EventHandler(this.BToperacekrat_Click);
            // 
            // BToperacedeleno
            // 
            this.BToperacedeleno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.BToperacedeleno.Location = new System.Drawing.Point(233, 91);
            this.BToperacedeleno.Name = "BToperacedeleno";
            this.BToperacedeleno.Size = new System.Drawing.Size(47, 37);
            this.BToperacedeleno.TabIndex = 8;
            this.BToperacedeleno.Text = ":";
            this.BToperacedeleno.UseVisualStyleBackColor = true;
            this.BToperacedeleno.Click += new System.EventHandler(this.BToperacedeleno_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(47, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(196, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = "B";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(299, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 37);
            this.button1.TabIndex = 11;
            this.button1.Text = "sin(A)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 180);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BToperacedeleno);
            this.Controls.Add(this.BToperacekrat);
            this.Controls.Add(this.BToperaceminus);
            this.Controls.Add(this.BToperaceplus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TBvysledek);
            this.Controls.Add(this.LBoperace);
            this.Controls.Add(this.TBcislo2);
            this.Controls.Add(this.TBcislo1);
            this.Name = "Form1";
            this.Text = "KALKULAČKA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TBcislo1;
        private System.Windows.Forms.TextBox TBcislo2;
        private System.Windows.Forms.Label LBoperace;
        private System.Windows.Forms.TextBox TBvysledek;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BToperaceplus;
        private System.Windows.Forms.Button BToperaceminus;
        private System.Windows.Forms.Button BToperacekrat;
        private System.Windows.Forms.Button BToperacedeleno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

