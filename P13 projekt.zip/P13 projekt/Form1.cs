﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BToperaceplus_Click(object sender, EventArgs e)
        {
            float c1, c2, v;
            c1 = Convert.ToSingle(TBcislo1.Text);
            c2 = Convert.ToSingle(TBcislo2.Text);
            v = c1 + c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "+";               // oprava labelu s operací
        }

        private void BToperaceminus_Click(object sender, EventArgs e)
        {
            float c1, c2, v;
            c1 = Convert.ToSingle(TBcislo1.Text);
            c2 = Convert.ToSingle(TBcislo2.Text);
            v = c1 - c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "-";
        }

        private void BToperacekrat_Click(object sender, EventArgs e)
        {
            float c1, c2, v;
            c1 = Convert.ToSingle(TBcislo1.Text);
            c2 = Convert.ToSingle(TBcislo2.Text);
            v = c1 * c2;
            TBvysledek.Text = v.ToString();
            LBoperace.Text = "x";
        }

        private void BToperacedeleno_Click(object sender, EventArgs e)
        {
            float c1, c2, v;
            c1 = Convert.ToSingle(TBcislo1.Text);
            c2 = Convert.ToSingle(TBcislo2.Text);
            if (c2 != 0)				// musíme zabránit dělení 0
                v = c1 / c2;
            else
                v = 999.999f;		 // indikace chyby nějaká velká hodnota
            TBvysledek.Text = v.ToString("0.000");
            LBoperace.Text = ":";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, v;
            a = Convert.ToDouble(TBcislo1.Text);
            v = Math.Sin(a*Math.PI/180);
            TBvysledek.Text = v.ToString();
        }
    }
}
