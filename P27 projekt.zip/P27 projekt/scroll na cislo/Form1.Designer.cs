﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hSBjednotky = new System.Windows.Forms.HScrollBar();
            this.hSBdesitky = new System.Windows.Forms.HScrollBar();
            this.hSBstovky = new System.Windows.Forms.HScrollBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tBhodnota = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // hSBjednotky
            // 
            this.hSBjednotky.LargeChange = 1;
            this.hSBjednotky.Location = new System.Drawing.Point(97, 23);
            this.hSBjednotky.Maximum = 9;
            this.hSBjednotky.Name = "hSBjednotky";
            this.hSBjednotky.Size = new System.Drawing.Size(415, 24);
            this.hSBjednotky.TabIndex = 2;
            this.hSBjednotky.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hSBjednotky_Scroll);
            // 
            // hSBdesitky
            // 
            this.hSBdesitky.LargeChange = 1;
            this.hSBdesitky.Location = new System.Drawing.Point(97, 47);
            this.hSBdesitky.Maximum = 9;
            this.hSBdesitky.Name = "hSBdesitky";
            this.hSBdesitky.Size = new System.Drawing.Size(415, 24);
            this.hSBdesitky.TabIndex = 3;
            this.hSBdesitky.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hSBdesitky_Scroll);
            // 
            // hSBstovky
            // 
            this.hSBstovky.LargeChange = 1;
            this.hSBstovky.Location = new System.Drawing.Point(97, 71);
            this.hSBstovky.Maximum = 9;
            this.hSBstovky.Name = "hSBstovky";
            this.hSBstovky.Size = new System.Drawing.Size(415, 24);
            this.hSBstovky.TabIndex = 4;
            this.hSBstovky.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hSBstovky_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "jednotky";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "desitky";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "stovky";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Nastavená hodnota:";
            // 
            // tBhodnota
            // 
            this.tBhodnota.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBhodnota.Location = new System.Drawing.Point(159, 145);
            this.tBhodnota.Name = "tBhodnota";
            this.tBhodnota.Size = new System.Drawing.Size(122, 26);
            this.tBhodnota.TabIndex = 11;
            this.tBhodnota.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tBhodnota.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBhodnota_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(115, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(380, 24);
            this.label7.TabIndex = 12;
            this.label7.Text = "0      1      2      3      4      5      6      7      8      9";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 205);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tBhodnota);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hSBstovky);
            this.Controls.Add(this.hSBdesitky);
            this.Controls.Add(this.hSBjednotky);
            this.Name = "Form1";
            this.Text = "scroll bar na cislo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar hSBjednotky;
        private System.Windows.Forms.HScrollBar hSBdesitky;
        private System.Windows.Forms.HScrollBar hSBstovky;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBhodnota;
        private System.Windows.Forms.Label label7;
    }
}

