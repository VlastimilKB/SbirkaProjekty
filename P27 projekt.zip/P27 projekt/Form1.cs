﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         private void Vypocet()
        {
            float hodnota = 0.0f;
            hodnota += (float)hSBstovky.Value * 100;
            hodnota += (float)hSBdesitky.Value * 10;
            hodnota += (float)hSBjednotky.Value * 1;
            hodnota += (float)hSBdesetiny.Value / 10;
            hodnota += (float)hSBsetiny.Value / 100;
            //MessageBox.Show(hodnota.ToString());
            tBhodnota.Text = String.Format("{0:0.00}", hodnota);
        }

         private void hSBsetiny_Scroll(object sender, ScrollEventArgs e)
         {
             Vypocet();
         }

         private void hSBdesetiny_Scroll(object sender, ScrollEventArgs e)
         {
             Vypocet();
         }

         private void hSBjednotky_Scroll(object sender, ScrollEventArgs e)
         {
             Vypocet();
         }

         private void hSBdesitky_Scroll(object sender, ScrollEventArgs e)
         {
             Vypocet();
         }

         private void hSBstovky_Scroll(object sender, ScrollEventArgs e)
         {
             Vypocet();
         }

         private void tBhodnota_KeyPress(object sender, KeyPressEventArgs e)
         {
             try    // osetreni mozne chyby formatu aby program nespadnul, vypise hlaseni viz sekce catch
             {
                 if (e.KeyChar == 13)       // reakce pouze na klávesu Enter = OD hexa, tedy 13 dekadicky
                 {
                     int stovky, desitky, jednotky, desetiny, setiny;
                     float hodnota;
                     hodnota = Convert.ToSingle(tBhodnota.Text);
                     stovky = (int)hodnota / 100;
                     hSBstovky.Value = stovky;
                     hodnota -=(stovky * 100);
                     desitky = (int)hodnota / 10;
                     hSBdesitky.Value = desitky;
                     hodnota -= (desitky * 10);
                     jednotky = (int)hodnota;
                     hSBjednotky.Value = jednotky;
                     hodnota -= jednotky;
                     desetiny = (int)(hodnota * 10);
                     hSBdesetiny.Value = desetiny;
                     hodnota -=((float) desetiny / 10);
                     setiny = (int)(hodnota * 100);
                     hSBsetiny.Value = setiny;
                 }
             }
             catch      // v pripade chyby se vypise text, program pokracuje dale
             {
                 MessageBox.Show("Špatný formát - musí to být čí­slo!");
             }
         }
    }
}
