using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private Bitmap Vykres;
		private Pen Tuzka;
		private System.Windows.Forms.Panel panel1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Location = new System.Drawing.Point(40, 40);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(504, 280);
			this.panel1.TabIndex = 1;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
			// 
			// Form1
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(584, 363);
			this.Controls.Add(this.panel1);
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(600, 400);
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(600, 400);
			this.Name = "Form1";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Graf";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		const int m = 61;
		public float pasmo = 4f*Convert.ToSingle(Math.PI);
		private float[] x = new float[m];
		private float[] y = new float[m];

		private void graf()
		{
			float krok = pasmo/(m-1);
			for(int i=0;i<m;i++)
			{
				x[i] = pasmo/-2+i*krok;
				if(x[i] != 0f)
					y[i] = Convert.ToSingle(Math.Sin(x[i]))/x[i];
				else
					y[i] = Convert.ToSingle(Math.Cos(x[i]));
			}

			Graphics kreslim;
			kreslim = Graphics.FromImage(Vykres);
			Tuzka.Color = Color.Black;
            Tuzka.Width = 1;
			kreslim.DrawLine(Tuzka,Vykres.Width/2,0,Vykres.Width/2,Vykres.Height);
			kreslim.DrawLine(Tuzka,0,Vykres.Height*3/4,Vykres.Width,Vykres.Height*3/4);
			Tuzka.Color = Color.Red;
			Tuzka.Width = 1.4f;
			FontFamily a = new FontFamily("Arial");
			for(int i=0;i<m-1;i++)
				kreslim.DrawLine(Tuzka,x[i]*30+Vykres.Width/2,-y[i]*180+Vykres.Height*3/4,x[i+1]*30+Vykres.Width/2,-y[i+1]*180+Vykres.Height*3/4);
			
			kreslim.DrawString("0",new Font(a,10),Brushes.Black,Vykres.Width/2+3,Vykres.Height/2+70);
			kreslim.DrawString("x",new Font(a,10),Brushes.Black,Vykres.Width-30,Vykres.Height/2+70);
			kreslim.DrawString("y",new Font(a,10),Brushes.Black,Vykres.Width/2+3,5);
			kreslim.DrawString("sin x/x",new Font(a,10),Brushes.Black,20,20);
			kreslim.Dispose();
			panel1.Invalidate();
		}

		private void panel_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics k;
			k = e.Graphics;
			k.DrawImage(Vykres,0,0,Vykres.Width,Vykres.Height);
			k.Dispose();
		}

		private void pozadi()
		{
			Graphics kreslim;
			kreslim = Graphics.FromImage(Vykres);
			Tuzka = new Pen(Color.White);
			for(int i=0;i<Vykres.Width;i++)
                kreslim.DrawLine(Tuzka,i,0,i,Vykres.Height);
			kreslim.Dispose();
			panel1.Invalidate();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			Vykres = new Bitmap(panel1.ClientRectangle.Width,panel1.ClientRectangle.Height,System.Drawing.Imaging.PixelFormat.Format24bppRgb);
			pozadi();
			graf();
		}
	}
}
