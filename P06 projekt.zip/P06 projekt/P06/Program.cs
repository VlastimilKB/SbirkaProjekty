﻿using System;

namespace ConsoleOdkazHodnota
{
    class Program
    {
        static int SectiHodnoty(int a, int b)          // volani hodnotou
        {
            return (a + b);      // výsledek se vraci pomocí příkazu return
        }

        static void SectiHodnotyOdkazem(int a, int b, out int v)
        // deklarace odkazem out 
        {
            v = a + b;
        }

        static void OdectiHodnotyOdkazem(int a, int b, ref int v)
        // deklarace odkazem ref
        {
            v = a - b;
        }

        static void Main(string[] args)
        {
            int c = 5, d = 10, v, vOdkaz = 0;
            // pro ref musí mít proměnná předem hodnotu
            v = SectiHodnoty(c, d);
            Console.WriteLine("Pomoci volani hodnotou je vysledek " + v);
            SectiHodnotyOdkazem(c, d, out v);
            Console.WriteLine("Pomoci volani odkazem  je vysledek " + v);
            OdectiHodnotyOdkazem(c, d, ref vOdkaz);
            Console.WriteLine("Pomoci volani odkazem  je vysledek " +
                               vOdkaz);
            Console.ReadLine();
        }
    }
}

