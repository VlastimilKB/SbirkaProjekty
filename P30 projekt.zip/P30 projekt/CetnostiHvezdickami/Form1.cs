﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ViceFormularu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Form2 InstanceForm2 = new Form2();

        private void button1_Click(object sender, EventArgs e)
        {
            InstanceForm2.Owner = this;     // this je jako form1, je vlastnikem druheho formulare
            InstanceForm2.Show();           // ukažeme druhy formulář s četnostmi graficky hvezdickami
            
        }

        private string Hvezdicky(int n)     // navraci retezec obsahujici n-hvezdicek
        {
            string h = "";
            for (int i = 0; i < n; i++)
                h += "*";
            return h;
        }

        private void button2_Click(object sender, EventArgs e)      // generujeme 100 náh. čísel
        {
            Random G = new Random();
            int[] cisla = new int[100];
            int[] interval = new int[10];   // 10 intervalu pro rozsahy hodnot: 0-9,10-19,...,90-99

            listBox1.Items.Clear();
            listBox2.Items.Clear();
            InstanceForm2.rtbCetnosti.Text = "";    // vymazeme rtb na druhem formulari

            for(int i=0; i<100; i++){
                cisla[i]=G.Next(100);                       // čísla z intervalu 0 - 99
                listBox1.Items.Add(cisla[i].ToString());
                interval[cisla[i] / 10]++;       // zjistime, ktery je to interval, a zvysime citac o 1
            }
            for (int i = 0; i < 10; i++)
            {
                listBox2.Items.Add((10*i).ToString("00")+ " - " + (10*i+9).ToString("00") + " = " 
                    + interval[i].ToString());
                InstanceForm2.rtbCetnosti.Text += (10 * i).ToString("00") + " - " + 
                    (10 * i + 9).ToString("00");
                InstanceForm2.rtbCetnosti.Text += "  "+interval[i].ToString("00");
                InstanceForm2.rtbCetnosti.Text += "   " + Hvezdicky(interval[i]);
                InstanceForm2.rtbCetnosti.Text += "\x0A";       // vlozime enter do rich text boxu
            }
        }
    }
}
