﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinSimplePaintBrush
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            g = pnl_Draw.CreateGraphics();
            pnl_Draw.BackColor = Color.White;
        }

        bool startPaint = false;
        Graphics g;
           // pokud chceme dosadit do int prázdnou hodnotu null, tak označíme ? (nullable int)
        int? initX = null;
        int? initY = null;
        bool drawSquare = false;
        bool drawRectangle = false;
        bool drawCircle = false;
        bool drawTriangle = false;
        bool drawStar = false;
        bool drawText = false;
        bool drawSpray = false;
        private Random nahcislo = new Random();

        private void pnl_Draw_MouseMove(object sender, MouseEventArgs e)
        {
            if (startPaint)
            {
                   // Nastavení barvy kreslení podle pozadí tlačítka btn_BackColor a sirku cary podle hodnoty Combo Boxu
                Pen p = new Pen(btn_PenColor.BackColor, float.Parse(cmb_PenSize.Text));
                        // kreslíme caru - spojnici podle polohy mysi nad objektem g
                        // poloha noveho bodu je ulozena v parametru e.X a e.Y
                g.DrawLine(p, new Point(initX ?? e.X, initY ?? e.Y), new Point(e.X, e.Y));
                initX = e.X;        // uschovame si predchozi polohu bodu pro dalsi pohyb mysi
                initY = e.Y;
            }
        }

        private void pnl_Draw_MouseDown(object sender, MouseEventArgs e)
        {
            startPaint = true;      // zaciname kreslit tak nastavime true
            if (drawSquare)
            {
                        // nastaveni barvy Solid Brush pro vyplne obrazcu 
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                        // sirka a vyska pro zakresleni ctverce je hodnota z Textboxu txt_ShapeSize
                g.FillRectangle(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                        // upravime startPaint a drawSquare na false, protože se to provede jen jednou na klik v miste
                startPaint = false;
                drawSquare = false;
            }
            if (drawRectangle)
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                        // sirka je dvojnasobna nez vyska pro zakresleni obdelniku
                g.FillRectangle(sb, e.X, e.Y, 2 * int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                startPaint = false;
                drawRectangle = false;
            }
            if (drawCircle)         // kreslime kruh vybranou barvou
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                g.FillEllipse(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                startPaint = false;
                drawCircle = false;
            }
            if (drawTriangle)       // kreslime trojuhelnik na pozici mysi
            {
                Pen p = new Pen(btn_PenColor.BackColor, float.Parse(cmb_PenSize.Text));
                int vel=int.Parse(txt_ShapeSize.Text);
                g.DrawLine(p,e.X,e.Y,e.X+vel/1.5f,e.Y+vel);
                g.DrawLine(p, e.X+vel/1.5f, e.Y+vel, e.X - vel/1.5f, e.Y + vel);
                g.DrawLine(p, e.X-vel/1.5f, e.Y+vel, e.X, e.Y);
                startPaint = false;
                drawTriangle = false;
            }
            if (drawStar)           // kreslime hvezdicku se stredem na poloze mysi
            {
                Pen p = new Pen(btn_PenColor.BackColor, float.Parse(cmb_PenSize.Text));
                int v = int.Parse(txt_ShapeSize.Text);
                g.DrawLine(p, e.X - v, e.Y, e.X + v, e.Y);
                g.DrawLine(p, e.X, e.Y-v, e.X, e.Y+v);
                g.DrawLine(p, e.X-v*0.7f, e.Y-v*0.7f, e.X+v*0.7f, e.Y+v*0.7f);
                g.DrawLine(p, e.X - v * 0.7f, e.Y + v * 0.7f, e.X + v * 0.7f, e.Y - v * 0.7f);
                startPaint = false;
                drawStar = false;
            }
            if (drawText)           // kreslíme text vybraným fontem ze seznamu dostupných fontů
            {
                string s,VybranyFont;
                int velikost;
                velikost=Convert.ToInt16(txt_ShapeSize.Text);
                s=tbUkazka.Text;
                VybranyFont = listBox1.Items[listBox1.SelectedIndex].ToString();
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                Font myfont = new Font(VybranyFont,velikost);
                g.DrawString(s, myfont,sb, e.X, e.Y);
                startPaint = false;
                drawText = false;
            }
            if (drawSpray)
            {
                int radius = Convert.ToInt16(txt_ShapeSize.Text);   // polomer kruhu pro spray
                Pen p = new Pen(btn_PenColor.BackColor, 2.0f);      // nastavime si barvu tecek
                for (int i = 0; i < 200; ++i)
                {
                        // vytvorime si nahodne Polarni souradnice
                        // uhel theta je náhodne cislo mezi 0 az 2*PI
                        // r          je nahodne cislo mezi 0 az radius
                    double theta = nahcislo.NextDouble() * (Math.PI * 2);
                    double r = nahcislo.NextDouble() * radius;
                        // Transformujeme polarni souradnice do kartezskych (x,y)
                        // a vybereme stred podle polohy mysi 
                    double x = e.X + Math.Cos(theta) * r;
                    double y = e.Y + Math.Sin(theta) * r;   // zakreslime si jednu tecku
                    g.DrawEllipse(p, new Rectangle((int)x - 1, (int)y - 1, 1, 1));
                }
                startPaint = false;
            }

        }

        private void pnl_Draw_MouseUp(object sender, MouseEventArgs e)
        {
            startPaint = false;         // prestavam kreslit tak nastavim false
            initX = null;
            initY = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
                // Otevreni systemoveho dialogu windows pro vyber barvy pro kresleni
            ColorDialog c = new ColorDialog();
            if (c.ShowDialog() == DialogResult.OK)
            {
                btn_PenColor.BackColor = c.Color;
            }
        }

        private void btn_Square_Click(object sender, EventArgs e)
        {
            drawSquare = true;
        }

        private void btn_Rectangle_Click(object sender, EventArgs e)
        {
            drawRectangle = true;
        }

        private void btn_Circle_Click(object sender, EventArgs e)
        {
            drawCircle = true;
        }

        private void btn_vymazat_Click(object sender, EventArgs e)
        {
            pnl_Draw.BackColor = Color.White;
            pnl_Draw.Invalidate();
        }

        private void btnTriangle_Click(object sender, EventArgs e)
        {
            drawTriangle = true;
        }

        private void btnStar_Click(object sender, EventArgs e)
        {
            drawStar = true;
        }

        private void pnl_Draw_MouseClick(object sender, MouseEventArgs e)
        {
            int x, y;               // pozice kliknuti mysi
            x = e.X; y = e.Y;
            textBox1.Text = "  x=" + x + " y=" + y;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (FontFamily oneFontFamily in FontFamily.Families)
            {
                listBox1.Items.Add(oneFontFamily.Name);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string VybranyFont,Abeceda;
            VybranyFont = listBox1.Items[listBox1.SelectedIndex].ToString();
            tbVybranyFont.Text = VybranyFont;
            Abeceda = "ABC...0123... abc";
            Font myfont = new Font(VybranyFont, 24.0f);
            tbUkazka.Font = myfont;
            tbUkazka.Text = Abeceda;
        }

        private void btnText_Click(object sender, EventArgs e)
        {
            drawText = true;
        }

        private void btnSpray_Click(object sender, EventArgs e)
        {
            if (btnSpray.Text == "SprayOff")
            {
                drawSpray = true;
                btnSpray.Text = "SprayOn";
            }
            else
            {
                drawSpray = false;
                btnSpray.Text = "SprayOff";
            }
        }                        
    }
}
