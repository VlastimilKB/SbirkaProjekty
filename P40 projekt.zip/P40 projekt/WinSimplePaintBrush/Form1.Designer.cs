﻿namespace WinSimplePaintBrush
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Draw = new System.Windows.Forms.PictureBox();
            this.cmb_PenSize = new System.Windows.Forms.ComboBox();
            this.btn_PenColor = new System.Windows.Forms.Button();
            this.txt_ShapeSize = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_Square = new System.Windows.Forms.Button();
            this.btn_Rectangle = new System.Windows.Forms.Button();
            this.btn_Circle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_vymazat = new System.Windows.Forms.Button();
            this.btnTriangle = new System.Windows.Forms.Button();
            this.btnStar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbVybranyFont = new System.Windows.Forms.TextBox();
            this.tbUkazka = new System.Windows.Forms.TextBox();
            this.btnText = new System.Windows.Forms.Button();
            this.btnSpray = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pnl_Draw)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_Draw
            // 
            this.pnl_Draw.Location = new System.Drawing.Point(251, 22);
            this.pnl_Draw.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnl_Draw.Name = "pnl_Draw";
            this.pnl_Draw.Size = new System.Drawing.Size(794, 745);
            this.pnl_Draw.TabIndex = 0;
            this.pnl_Draw.TabStop = false;
            this.pnl_Draw.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pnl_Draw_MouseClick);
            this.pnl_Draw.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnl_Draw_MouseDown);
            this.pnl_Draw.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnl_Draw_MouseMove);
            this.pnl_Draw.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnl_Draw_MouseUp);
            // 
            // cmb_PenSize
            // 
            this.cmb_PenSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cmb_PenSize.FormattingEnabled = true;
            this.cmb_PenSize.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "10",
            "12",
            "14",
            "16"});
            this.cmb_PenSize.Location = new System.Drawing.Point(51, 79);
            this.cmb_PenSize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_PenSize.Name = "cmb_PenSize";
            this.cmb_PenSize.Size = new System.Drawing.Size(151, 30);
            this.cmb_PenSize.TabIndex = 1;
            this.cmb_PenSize.Text = " vyber tloustku";
            // 
            // btn_PenColor
            // 
            this.btn_PenColor.Enabled = false;
            this.btn_PenColor.Location = new System.Drawing.Point(46, 209);
            this.btn_PenColor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_PenColor.Name = "btn_PenColor";
            this.btn_PenColor.Size = new System.Drawing.Size(149, 52);
            this.btn_PenColor.TabIndex = 2;
            this.btn_PenColor.UseVisualStyleBackColor = true;
            // 
            // txt_ShapeSize
            // 
            this.txt_ShapeSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txt_ShapeSize.Location = new System.Drawing.Point(51, 318);
            this.txt_ShapeSize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_ShapeSize.Name = "txt_ShapeSize";
            this.txt_ShapeSize.Size = new System.Drawing.Size(140, 30);
            this.txt_ShapeSize.TabIndex = 3;
            this.txt_ShapeSize.Text = "25";
            this.txt_ShapeSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(47, 153);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 52);
            this.button1.TabIndex = 4;
            this.button1.Text = "Vyber barvu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Square
            // 
            this.btn_Square.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_Square.Location = new System.Drawing.Point(71, 371);
            this.btn_Square.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Square.Name = "btn_Square";
            this.btn_Square.Size = new System.Drawing.Size(120, 39);
            this.btn_Square.TabIndex = 8;
            this.btn_Square.Text = "ctverec";
            this.btn_Square.UseVisualStyleBackColor = true;
            this.btn_Square.Click += new System.EventHandler(this.btn_Square_Click);
            // 
            // btn_Rectangle
            // 
            this.btn_Rectangle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_Rectangle.Location = new System.Drawing.Point(71, 424);
            this.btn_Rectangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Rectangle.Name = "btn_Rectangle";
            this.btn_Rectangle.Size = new System.Drawing.Size(120, 39);
            this.btn_Rectangle.TabIndex = 9;
            this.btn_Rectangle.Text = "obdelnik";
            this.btn_Rectangle.UseVisualStyleBackColor = true;
            this.btn_Rectangle.Click += new System.EventHandler(this.btn_Rectangle_Click);
            // 
            // btn_Circle
            // 
            this.btn_Circle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_Circle.Location = new System.Drawing.Point(71, 477);
            this.btn_Circle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Circle.Name = "btn_Circle";
            this.btn_Circle.Size = new System.Drawing.Size(120, 39);
            this.btn_Circle.TabIndex = 10;
            this.btn_Circle.Text = "kruh";
            this.btn_Circle.UseVisualStyleBackColor = true;
            this.btn_Circle.Click += new System.EventHandler(this.btn_Circle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(62, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tloustka cary";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(53, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 25);
            this.label2.TabIndex = 12;
            this.label2.Text = "Velikost obrazce";
            // 
            // btn_vymazat
            // 
            this.btn_vymazat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_vymazat.Location = new System.Drawing.Point(67, 710);
            this.btn_vymazat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_vymazat.Name = "btn_vymazat";
            this.btn_vymazat.Size = new System.Drawing.Size(120, 39);
            this.btn_vymazat.TabIndex = 13;
            this.btn_vymazat.Text = "vymazat...";
            this.btn_vymazat.UseVisualStyleBackColor = true;
            this.btn_vymazat.Click += new System.EventHandler(this.btn_vymazat_Click);
            // 
            // btnTriangle
            // 
            this.btnTriangle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnTriangle.Location = new System.Drawing.Point(71, 567);
            this.btnTriangle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTriangle.Name = "btnTriangle";
            this.btnTriangle.Size = new System.Drawing.Size(116, 39);
            this.btnTriangle.TabIndex = 14;
            this.btnTriangle.Text = "triangle";
            this.btnTriangle.UseVisualStyleBackColor = true;
            this.btnTriangle.Click += new System.EventHandler(this.btnTriangle_Click);
            // 
            // btnStar
            // 
            this.btnStar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnStar.Location = new System.Drawing.Point(71, 620);
            this.btnStar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStar.Name = "btnStar";
            this.btnStar.Size = new System.Drawing.Size(120, 39);
            this.btnStar.TabIndex = 15;
            this.btnStar.Text = "hvezda";
            this.btnStar.UseVisualStyleBackColor = true;
            this.btnStar.Click += new System.EventHandler(this.btnStar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(1076, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Pozice click";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(1081, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(151, 28);
            this.textBox1.TabIndex = 17;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(1081, 156);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(338, 276);
            this.listBox1.TabIndex = 18;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(1076, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 25);
            this.label4.TabIndex = 19;
            this.label4.Text = "Seznam fontů:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(1243, 100);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(176, 48);
            this.button2.TabIndex = 20;
            this.button2.Text = "Načtení fontů";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(1076, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "Vybraný font:";
            // 
            // tbVybranyFont
            // 
            this.tbVybranyFont.Location = new System.Drawing.Point(1084, 494);
            this.tbVybranyFont.Name = "tbVybranyFont";
            this.tbVybranyFont.Size = new System.Drawing.Size(335, 22);
            this.tbVybranyFont.TabIndex = 22;
            // 
            // tbUkazka
            // 
            this.tbUkazka.Location = new System.Drawing.Point(1084, 544);
            this.tbUkazka.Name = "tbUkazka";
            this.tbUkazka.Size = new System.Drawing.Size(335, 22);
            this.tbUkazka.TabIndex = 23;
            // 
            // btnText
            // 
            this.btnText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnText.Location = new System.Drawing.Point(1152, 620);
            this.btnText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnText.Name = "btnText";
            this.btnText.Size = new System.Drawing.Size(208, 39);
            this.btnText.TabIndex = 24;
            this.btnText.Text = "Zakresli text";
            this.btnText.UseVisualStyleBackColor = true;
            this.btnText.Click += new System.EventHandler(this.btnText_Click);
            // 
            // btnSpray
            // 
            this.btnSpray.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSpray.Location = new System.Drawing.Point(1152, 674);
            this.btnSpray.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSpray.Name = "btnSpray";
            this.btnSpray.Size = new System.Drawing.Size(208, 39);
            this.btnSpray.TabIndex = 25;
            this.btnSpray.Text = "SprayOff";
            this.btnSpray.UseVisualStyleBackColor = true;
            this.btnSpray.Click += new System.EventHandler(this.btnSpray_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1442, 784);
            this.Controls.Add(this.btnSpray);
            this.Controls.Add(this.btnText);
            this.Controls.Add(this.tbUkazka);
            this.Controls.Add(this.tbVybranyFont);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnStar);
            this.Controls.Add(this.btnTriangle);
            this.Controls.Add(this.btn_vymazat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Circle);
            this.Controls.Add(this.btn_Rectangle);
            this.Controls.Add(this.btn_Square);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_ShapeSize);
            this.Controls.Add(this.btn_PenColor);
            this.Controls.Add(this.cmb_PenSize);
            this.Controls.Add(this.pnl_Draw);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Mini Paint";
            ((System.ComponentModel.ISupportInitialize)(this.pnl_Draw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pnl_Draw;
        private System.Windows.Forms.ComboBox cmb_PenSize;
        private System.Windows.Forms.Button btn_PenColor;
        private System.Windows.Forms.TextBox txt_ShapeSize;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_Square;
        private System.Windows.Forms.Button btn_Rectangle;
        private System.Windows.Forms.Button btn_Circle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_vymazat;
        private System.Windows.Forms.Button btnTriangle;
        private System.Windows.Forms.Button btnStar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbVybranyFont;
        private System.Windows.Forms.TextBox tbUkazka;
        private System.Windows.Forms.Button btnText;
        private System.Windows.Forms.Button btnSpray;
    }
}

