﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double Faktorial(int x)
        {
            double v = 2;
            for (int h = 3; h <= x; h++)
                v *= h;
            return(v);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int h;
            double F;
            h = Convert.ToInt16(tbHodnota.Text);
            F = Faktorial(h);
            tbFaktorial.Text = F.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int n,k;
            double NnadK;
            n = Convert.ToInt16(tbN.Text);
            k = Convert.ToInt16(tbK.Text);
            NnadK = Faktorial(n) / (Faktorial(k) * Faktorial(n - k));
            tbNnadK.Text = NnadK.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int n, k;
            double Permutace;
            n = Convert.ToInt16(tbN.Text);
            k = Convert.ToInt16(tbK.Text);
            Permutace = Faktorial(n) / Faktorial(n - k);
            tbPermutace.Text = Permutace.ToString();
        }
    }
}
