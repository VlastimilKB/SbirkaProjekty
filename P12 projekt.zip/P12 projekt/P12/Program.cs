﻿using System;

namespace ConsoleFaktura
{
    class Faktura
    {
        private int pocetkusu, dph;
        private double cbd1ks, csd1ks, ccbd, ccsd;

        public Faktura(int Pocetkusu, int Dph, double Cbd1ks)	
                                                           // konstruktor 1
        {
            pocetkusu = Pocetkusu;
            dph = Dph;
            cbd1ks = Cbd1ks;
        }

        public Faktura()    // konstruktor 2 bez parametru nutne pro tvorbu 
                            // pole objektu
        {
            pocetkusu = 0;
            dph = 0;
            cbd1ks = 0;
        }

        public void Vypocet()	    // vypocet zbyvajicich polozek na fakture
        {
            csd1ks = cbd1ks * (1 + dph / 100.0);
            ccbd = pocetkusu * cbd1ks;
            ccsd = csd1ks * pocetkusu;
        }

        public int Pocetkusu()
        { return pocetkusu; }

        public int Dph()
        { return dph; }

        public double Cbd1ks()			// cena bez dane za kus
        { return cbd1ks; }

        public double Csd1ks()			// cena s daní	za kus
        { return csd1ks; }

        public double Ccbd()			     // celkova cena bez dane
        { return ccbd; }

        public double Ccsd()			     // celkova cena s dani
        { return ccsd; }

        public void Nastavit(int a, int b, double c)		
                           // nastaveni hodnot faktury podobne konstruktoru
        {
            pocetkusu = a;
            dph = b;
            cbd1ks = c;
        }
    };

    class Program
    {
        static void Main(string[] args)
        {           
            Faktura[] F= new Faktura[4];     // pole objektů třídy Faktura
            int pom, pom1;
            double pom2, suma = 0;
            for (int i = 0; i < 4; i++)     // cyklus pro 4 polozky faktury
            {
                Console.Write("\nZadejte pocet kusu "+(i+1)+". polozky:");
                pom=Convert.ToInt16(Console.ReadLine());

                Console.Write("Zadejte DPH        "+(i+1)+". polozky:");
                pom1 = Convert.ToInt16(Console.ReadLine());

                Console.Write("Zadejte cenu bez dane "+(i+1)+". polozky:");
                pom2 = Convert.ToDouble(Console.ReadLine());

                F[i] = new Faktura();        // požádáme o 1 novou instanci     
                                             // položky faktury
                F[i].Nastavit(pom, pom1, pom2);     // předáme hodnoty do 
                                                    // faktury
                F[i].Vypocet();                     // provedeme výpocet
                suma += F[i].Ccsd();          // pricteme k celkove cene
            }
            
            Console.WriteLine("\nREKAPITULACE FAKTURY\n");
            Console.WriteLine("pocks  dph  cbd1ks  csd1ks   ccbd     ccsd\n");
            for (int i = 0; i < 4; i++)
            {
                Console.Write("  " + F[i].Pocetkusu().ToString() + "      " 
               + F[i].Dph().ToString() + "   " + F[i].Cbd1ks().ToString());
                Console.Write("  "+F[i].Csd1ks().ToString());
                Console.Write("  "+F[i].Ccbd().ToString());
                Console.WriteLine("  "+F[i].Ccsd().ToString());
            }
            Console.WriteLine("\nCena faktury celkem s DPH = " + 
                               suma.ToString()+" Kč");
	      Console.ReadLine();
        }
    }
}

