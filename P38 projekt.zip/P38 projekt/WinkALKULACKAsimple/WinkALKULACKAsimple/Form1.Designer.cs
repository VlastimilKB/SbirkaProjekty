﻿namespace WinkALKULACKAsimple
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonTecka = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonDeleno = new System.Windows.Forms.Button();
            this.buttonKrat = new System.Windows.Forms.Button();
            this.buttonVysledek = new System.Windows.Forms.Button();
            this.buttonFaktorial = new System.Windows.Forms.Button();
            this.buttonLN = new System.Windows.Forms.Button();
            this.buttonLog10 = new System.Windows.Forms.Button();
            this.buttonModulo = new System.Windows.Forms.Button();
            this.buttonSinus = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.butDegRad = new System.Windows.Forms.Button();
            this.buttonCosinus = new System.Windows.Forms.Button();
            this.buttonTangens = new System.Windows.Forms.Button();
            this.buttonVypnout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("SimSun-ExtB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox1.Location = new System.Drawing.Point(135, 31);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(387, 50);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(16, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 60);
            this.button1.TabIndex = 1;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(150, 107);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 60);
            this.button2.TabIndex = 2;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(284, 107);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(115, 60);
            this.button3.TabIndex = 3;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.Location = new System.Drawing.Point(16, 194);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 60);
            this.button4.TabIndex = 4;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(150, 194);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 60);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button6.Location = new System.Drawing.Point(288, 194);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(115, 60);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button7.Location = new System.Drawing.Point(16, 284);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(115, 60);
            this.button7.TabIndex = 7;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button8.Location = new System.Drawing.Point(150, 284);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(115, 60);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button9.Location = new System.Drawing.Point(284, 284);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(115, 60);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button0.Location = new System.Drawing.Point(16, 371);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(115, 60);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // buttonC
            // 
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonC.Location = new System.Drawing.Point(553, 21);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(115, 60);
            this.buttonC.TabIndex = 11;
            this.buttonC.Text = "Clear";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // buttonTecka
            // 
            this.buttonTecka.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonTecka.Location = new System.Drawing.Point(150, 371);
            this.buttonTecka.Name = "buttonTecka";
            this.buttonTecka.Size = new System.Drawing.Size(115, 60);
            this.buttonTecka.TabIndex = 12;
            this.buttonTecka.Text = ".";
            this.buttonTecka.UseVisualStyleBackColor = true;
            this.buttonTecka.Click += new System.EventHandler(this.buttonTecka_Click);
            // 
            // buttonPlus
            // 
            this.buttonPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPlus.Location = new System.Drawing.Point(423, 107);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(115, 60);
            this.buttonPlus.TabIndex = 13;
            this.buttonPlus.Text = "+";
            this.buttonPlus.UseVisualStyleBackColor = true;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            // 
            // buttonMinus
            // 
            this.buttonMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonMinus.Location = new System.Drawing.Point(423, 194);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(115, 60);
            this.buttonMinus.TabIndex = 14;
            this.buttonMinus.Text = "-";
            this.buttonMinus.UseVisualStyleBackColor = true;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // buttonDeleno
            // 
            this.buttonDeleno.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonDeleno.Location = new System.Drawing.Point(423, 371);
            this.buttonDeleno.Name = "buttonDeleno";
            this.buttonDeleno.Size = new System.Drawing.Size(115, 60);
            this.buttonDeleno.TabIndex = 15;
            this.buttonDeleno.Text = "/";
            this.buttonDeleno.UseVisualStyleBackColor = true;
            this.buttonDeleno.Click += new System.EventHandler(this.buttonDeleno_Click);
            // 
            // buttonKrat
            // 
            this.buttonKrat.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonKrat.Location = new System.Drawing.Point(423, 284);
            this.buttonKrat.Name = "buttonKrat";
            this.buttonKrat.Size = new System.Drawing.Size(115, 60);
            this.buttonKrat.TabIndex = 16;
            this.buttonKrat.Text = "*";
            this.buttonKrat.UseVisualStyleBackColor = true;
            this.buttonKrat.Click += new System.EventHandler(this.buttonKrat_Click);
            // 
            // buttonVysledek
            // 
            this.buttonVysledek.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonVysledek.Location = new System.Drawing.Point(423, 454);
            this.buttonVysledek.Name = "buttonVysledek";
            this.buttonVysledek.Size = new System.Drawing.Size(115, 60);
            this.buttonVysledek.TabIndex = 17;
            this.buttonVysledek.Text = "=";
            this.buttonVysledek.UseVisualStyleBackColor = true;
            this.buttonVysledek.Click += new System.EventHandler(this.buttonVysledek_Click);
            // 
            // buttonFaktorial
            // 
            this.buttonFaktorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonFaktorial.Location = new System.Drawing.Point(288, 371);
            this.buttonFaktorial.Name = "buttonFaktorial";
            this.buttonFaktorial.Size = new System.Drawing.Size(115, 60);
            this.buttonFaktorial.TabIndex = 18;
            this.buttonFaktorial.Text = "n !";
            this.buttonFaktorial.UseVisualStyleBackColor = true;
            this.buttonFaktorial.Click += new System.EventHandler(this.buttonFaktorial_Click);
            // 
            // buttonLN
            // 
            this.buttonLN.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonLN.Location = new System.Drawing.Point(16, 454);
            this.buttonLN.Name = "buttonLN";
            this.buttonLN.Size = new System.Drawing.Size(115, 60);
            this.buttonLN.TabIndex = 19;
            this.buttonLN.Text = "Ln x";
            this.buttonLN.UseVisualStyleBackColor = true;
            this.buttonLN.Click += new System.EventHandler(this.buttonLN_Click);
            // 
            // buttonLog10
            // 
            this.buttonLog10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonLog10.Location = new System.Drawing.Point(150, 454);
            this.buttonLog10.Name = "buttonLog10";
            this.buttonLog10.Size = new System.Drawing.Size(115, 60);
            this.buttonLog10.TabIndex = 20;
            this.buttonLog10.Text = "Log10";
            this.buttonLog10.UseVisualStyleBackColor = true;
            this.buttonLog10.Click += new System.EventHandler(this.buttonLog10_Click);
            // 
            // buttonModulo
            // 
            this.buttonModulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonModulo.Location = new System.Drawing.Point(284, 454);
            this.buttonModulo.Name = "buttonModulo";
            this.buttonModulo.Size = new System.Drawing.Size(115, 60);
            this.buttonModulo.TabIndex = 21;
            this.buttonModulo.Text = "mod";
            this.buttonModulo.UseVisualStyleBackColor = true;
            this.buttonModulo.Click += new System.EventHandler(this.buttonModulo_Click);
            // 
            // buttonSinus
            // 
            this.buttonSinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonSinus.Location = new System.Drawing.Point(553, 194);
            this.buttonSinus.Name = "buttonSinus";
            this.buttonSinus.Size = new System.Drawing.Size(115, 60);
            this.buttonSinus.TabIndex = 22;
            this.buttonSinus.Text = "sin";
            this.buttonSinus.UseVisualStyleBackColor = true;
            this.buttonSinus.Click += new System.EventHandler(this.buttonSinus_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("SimSun-ExtB", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.textBox2.Location = new System.Drawing.Point(40, 31);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(91, 50);
            this.textBox2.TabIndex = 23;
            this.textBox2.Text = "deg";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // butDegRad
            // 
            this.butDegRad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.butDegRad.Location = new System.Drawing.Point(553, 107);
            this.butDegRad.Name = "butDegRad";
            this.butDegRad.Size = new System.Drawing.Size(115, 60);
            this.butDegRad.TabIndex = 24;
            this.butDegRad.Text = "Deg / Rad";
            this.butDegRad.UseVisualStyleBackColor = true;
            this.butDegRad.Click += new System.EventHandler(this.butDegRad_Click);
            // 
            // buttonCosinus
            // 
            this.buttonCosinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonCosinus.Location = new System.Drawing.Point(553, 284);
            this.buttonCosinus.Name = "buttonCosinus";
            this.buttonCosinus.Size = new System.Drawing.Size(115, 60);
            this.buttonCosinus.TabIndex = 25;
            this.buttonCosinus.Text = "cos";
            this.buttonCosinus.UseVisualStyleBackColor = true;
            this.buttonCosinus.Click += new System.EventHandler(this.buttonCosinus_Click);
            // 
            // buttonTangens
            // 
            this.buttonTangens.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonTangens.Location = new System.Drawing.Point(553, 371);
            this.buttonTangens.Name = "buttonTangens";
            this.buttonTangens.Size = new System.Drawing.Size(115, 60);
            this.buttonTangens.TabIndex = 26;
            this.buttonTangens.Text = "tan";
            this.buttonTangens.UseVisualStyleBackColor = true;
            this.buttonTangens.Click += new System.EventHandler(this.buttonTangens_Click);
            // 
            // buttonVypnout
            // 
            this.buttonVypnout.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonVypnout.Location = new System.Drawing.Point(553, 454);
            this.buttonVypnout.Name = "buttonVypnout";
            this.buttonVypnout.Size = new System.Drawing.Size(115, 60);
            this.buttonVypnout.TabIndex = 27;
            this.buttonVypnout.Text = "off";
            this.buttonVypnout.UseVisualStyleBackColor = true;
            this.buttonVypnout.Click += new System.EventHandler(this.buttonVypnout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 534);
            this.Controls.Add(this.buttonVypnout);
            this.Controls.Add(this.buttonTangens);
            this.Controls.Add(this.buttonCosinus);
            this.Controls.Add(this.butDegRad);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.buttonSinus);
            this.Controls.Add(this.buttonModulo);
            this.Controls.Add(this.buttonLog10);
            this.Controls.Add(this.buttonLN);
            this.Controls.Add(this.buttonFaktorial);
            this.Controls.Add(this.buttonVysledek);
            this.Controls.Add(this.buttonKrat);
            this.Controls.Add(this.buttonDeleno);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonPlus);
            this.Controls.Add(this.buttonTecka);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Jednoduchý kalkulátor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonTecka;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.Button buttonDeleno;
        private System.Windows.Forms.Button buttonKrat;
        private System.Windows.Forms.Button buttonVysledek;
        private System.Windows.Forms.Button buttonFaktorial;
        private System.Windows.Forms.Button buttonLN;
        private System.Windows.Forms.Button buttonLog10;
        private System.Windows.Forms.Button buttonModulo;
        private System.Windows.Forms.Button buttonSinus;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button butDegRad;
        private System.Windows.Forms.Button buttonCosinus;
        private System.Windows.Forms.Button buttonTangens;
        private System.Windows.Forms.Button buttonVypnout;
    }
}

