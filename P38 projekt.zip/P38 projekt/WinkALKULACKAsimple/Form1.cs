﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinkALKULACKAsimple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double PrvniCislo;      // globalni promenne plati ve vsech funkcich
        string Operace;

        private void DoplnitDisplej(string cifra)       // obecna funkce vyvolame 10 krat
        {
            if (textBox1.Text == "0" && textBox1.Text != null)
            {
                textBox1.Text = cifra;
            }
            else
            {
                textBox1.Text = textBox1.Text + cifra;
            }
        }

        private void button1_Click(object sender, EventArgs e)      // doplneni 1 na displej
        {
            DoplnitDisplej("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("4");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = button1;       // nastaveni focus na tlacitko 1 pri startu aplikace
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DoplnitDisplej("9");
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";  
        }

        private void buttonTecka_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ",";  
        }

        private void buttonC_Click(object sender, EventArgs e)      // Clear, vynulovat displej
        {
            textBox1.Text = "0";  
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            PrvniCislo = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operace= "+";  
        }

        private void buttonVysledek_Click(object sender, EventArgs e)       // provede se vypocet +-*/
        {
            double DruheCislo;
            double Result;

            DruheCislo = Convert.ToDouble(textBox1.Text);

            if (Operace == "+")
            {
                Result = (PrvniCislo + DruheCislo);
                textBox1.Text = Convert.ToString(Result);
                PrvniCislo = Result;
            }
            if (Operace == "-")
            {
                Result = (PrvniCislo - DruheCislo);
                textBox1.Text = Convert.ToString(Result);
                PrvniCislo = Result;
            }
            if (Operace == "*")
            {
                Result = (PrvniCislo * DruheCislo);
                textBox1.Text = Convert.ToString(Result);
                PrvniCislo = Result;
            }
            if (Operace == "/")
            {
                if (DruheCislo == 0)
                {
                    textBox1.Text = "Divide by zero";
                }
                else
                {
                    Result = (PrvniCislo / DruheCislo);
                                                      // zaokrouhlení na 3 desetinná čísla
                    textBox1.Text = Convert.ToString( Math.Round(Result, 3));
                    PrvniCislo = Result;
                }
            }
            if (Operace == "%")         // operace modulo
            {
                Result = (PrvniCislo % DruheCislo);
                textBox1.Text = Convert.ToString(Result);
                PrvniCislo = Result;
            }
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            PrvniCislo = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operace = "-";  
        }

        private void buttonKrat_Click(object sender, EventArgs e)
        {
            PrvniCislo = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operace = "*";  
        }

        private void buttonDeleno_Click(object sender, EventArgs e)
        {
            PrvniCislo = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operace = "/";
        }

        private void buttonFaktorial_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt16(textBox1.Text);
            double f = 1;
            if (n < 0)
            {
                MessageBox.Show("Neni definovane pro zaporne hodnoty");
                return;
            }
            for (int i = 2; i <= n; i++)
                f = f * i;
            if (f > 1e9)            // větší hodnoty budou v semilogaritmickém tvaru
                textBox1.Text = f.ToString("E6");
            else
                textBox1.Text = f.ToString();
        }

        private void buttonLN_Click(object sender, EventArgs e)
        {
            double x, v;
            x = Convert.ToDouble(textBox1.Text);
            v = Math.Log(x);                            // prirozeny logaritmus
            textBox1.Text = Convert.ToString(Math.Round(v, 6));
        }

        private void buttonLog10_Click(object sender, EventArgs e)
        {
            double x, v;
            x = Convert.ToDouble(textBox1.Text);
            v = Math.Log10(x);                          // dekadicky logaritmus
            textBox1.Text = Convert.ToString(Math.Round(v, 6));
        }

        private void buttonModulo_Click(object sender, EventArgs e)
        {
            PrvniCislo = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "0";
            Operace = "%";
        }

        private void buttonSinus_Click(object sender, EventArgs e)
        {
            double x, v;
            x = Convert.ToDouble(textBox1.Text);
            if(textBox2.Text=="deg")
                v = Math.Sin(x*Math.PI/180);                          // sinus
            else
                v = Math.Sin(x);        // uhel je v radianech  
            textBox1.Text = Convert.ToString(Math.Round(v, 6));
        }

        private void butDegRad_Click(object sender, EventArgs e)
        {
            if(textBox2.Text=="deg")
                textBox2.Text="rad";
            else
                textBox2.Text="deg";
        }

        private void buttonCosinus_Click(object sender, EventArgs e)
        {
            double x, v;
            x = Convert.ToDouble(textBox1.Text);
            if (textBox2.Text == "deg")
                v = Math.Cos(x * Math.PI / 180);                          // cosinus
            else
                v = Math.Cos(x);        // uhel je v radianech  
            textBox1.Text = Convert.ToString(Math.Round(v, 6));
        }

        private void buttonTangens_Click(object sender, EventArgs e)
        {
            double x, v;
            x = Convert.ToDouble(textBox1.Text);
            if (textBox2.Text == "deg")
                v = Math.Tan(x * Math.PI / 180);                          // tangens
            else
                v = Math.Tan(x);        // uhel je v radianech  
            textBox1.Text = Convert.ToString(Math.Round(v, 6));
        }

        private void buttonVypnout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
