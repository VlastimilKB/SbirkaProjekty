﻿using System;

namespace ConsoleKalkulacka
{
    class Program
    {
        static double faktorial(double n)	// funkce pro faktoriál
        {
            double v = 1.0;			// proměnná pro výsledek
            for (int i = 2; i <= n; i++)		// cyklus postupně nastavuje  
                // hodnotu proměnné i od 1 až po n
                v *= i;		   // v = v * i postupně násobíme do výsledku
            return v;
        }

        static double Vypocet(double x, char op, double y)
        {
            double v = 0;
            switch (op)
            {
                case '+': v = x + y; break;
                case '-': v = x - y; break;
                case '*': v = x * y; break;
                case '/': v = x / y; break;
                case 'n': v = faktorial(x) / faktorial(y) / faktorial(x - y);
                    break;            // n nad k kombinacni cislo
                default: Console.WriteLine("chybna operace"); break;
            }
            return v;
        }

        static void Main(string[] args)
        {
            double a, b, vysledek;
            char operace;
            Console.Write("zadej 1. operand: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("zadej operaci + - * / n = n nad k : ");
            operace = Convert.ToChar(Console.ReadLine());
            Console.Write("zadej 2. operand: ");
            b = Convert.ToDouble(Console.ReadLine());
            vysledek = Vypocet(a, operace, b);
            if (vysledek != 0)
                Console.Write(a.ToString() + " " + Convert.ToString
                             (operace) + " " + b.ToString() + " = " +
                             vysledek.ToString());
            Console.ReadLine();
        }
    }
}

