﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrevodyJednotek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tbCels_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar==13)
            {
                float C, F;
                C = Convert.ToSingle(tbCels.Text);
                F = (C * 9) / 5 + 32;
                tbFahr.Text = F.ToString("0.00");
            }
        }

        private void tbFahr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                float C, F;
                F = Convert.ToSingle(tbFahr.Text);
                C = (F - 32) * 5 / 9;
                tbCels.Text = C.ToString("0.00");
            }
        }

        private void tbLna100km_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                float Lna100km, mpg, mil, gal;
                const float Mile=1.602f;
                const float Galon=3.78f;
                Lna100km = Convert.ToSingle(tbLna100km.Text);
                mil = 100 / Mile;
                gal = Lna100km / Galon;
                mpg = mil / gal;
                tbMpg.Text = mpg.ToString("0.00");
            }
        }

        private void tbMpg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                float Lna100km, mpg, km;
                const float Mile = 1.602f;
                const float Galon = 3.78f;
                mpg = Convert.ToSingle(tbMpg.Text);
                km = mpg* Mile;
                Lna100km = 100/km*Galon;
                tbLna100km.Text = Lna100km.ToString("0.00");
            }
        }

        private void tbKnot_TextChanged(object sender, EventArgs e)
        {
            float knot, kmh;
            const float KNOT = 1.852f;      // rychlost 1 nautical miles/hour
            knot = Convert.ToSingle(tbKnot.Text);
            kmh = knot * KNOT;
            tbKMH.Enabled = false;
            tbKMH.Text = kmh.ToString();
            tbKMH.Enabled = true;
            // jak nastavit focus zpet sem??
        }

        private void tbKMH_TextChanged(object sender, EventArgs e)
        {
            float knot, kmh;
            const float KNOT = 1.852f;      // rychlost 1 nautical miles/hour
            kmh = Convert.ToSingle(tbKMH.Text);
            knot = kmh / KNOT;
            tbKnot.Enabled = false;
            tbKnot.Text = knot.ToString();
            tbKnot.Enabled = true;
        }
    }
}
