﻿namespace PrevodyJednotek
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCels = new System.Windows.Forms.TextBox();
            this.tbFahr = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbLna100km = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbMpg = new System.Windows.Forms.TextBox();
            this.tbKMH = new System.Windows.Forms.TextBox();
            this.tbKnot = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(13, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Celsius:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(13, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Fahrenheit:";
            // 
            // tbCels
            // 
            this.tbCels.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbCels.Location = new System.Drawing.Point(115, 18);
            this.tbCels.Name = "tbCels";
            this.tbCels.Size = new System.Drawing.Size(79, 24);
            this.tbCels.TabIndex = 2;
            this.tbCels.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbCels.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCels_KeyPress);
            // 
            // tbFahr
            // 
            this.tbFahr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbFahr.Location = new System.Drawing.Point(115, 53);
            this.tbFahr.Name = "tbFahr";
            this.tbFahr.Size = new System.Drawing.Size(79, 24);
            this.tbFahr.TabIndex = 3;
            this.tbFahr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFahr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFahr_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(240, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "l / 100 km";
            // 
            // tbLna100km
            // 
            this.tbLna100km.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbLna100km.Location = new System.Drawing.Point(322, 20);
            this.tbLna100km.Name = "tbLna100km";
            this.tbLna100km.Size = new System.Drawing.Size(79, 24);
            this.tbLna100km.TabIndex = 5;
            this.tbLna100km.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbLna100km.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbLna100km_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(240, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "mpg";
            // 
            // tbMpg
            // 
            this.tbMpg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbMpg.Location = new System.Drawing.Point(322, 57);
            this.tbMpg.Name = "tbMpg";
            this.tbMpg.Size = new System.Drawing.Size(79, 24);
            this.tbMpg.TabIndex = 7;
            this.tbMpg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbMpg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMpg_KeyPress);
            // 
            // tbKMH
            // 
            this.tbKMH.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbKMH.Location = new System.Drawing.Point(115, 149);
            this.tbKMH.Name = "tbKMH";
            this.tbKMH.Size = new System.Drawing.Size(79, 24);
            this.tbKMH.TabIndex = 11;
            this.tbKMH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbKMH.TextChanged += new System.EventHandler(this.tbKMH_TextChanged);
            // 
            // tbKnot
            // 
            this.tbKnot.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbKnot.Location = new System.Drawing.Point(115, 114);
            this.tbKnot.Name = "tbKnot";
            this.tbKnot.Size = new System.Drawing.Size(79, 24);
            this.tbKnot.TabIndex = 10;
            this.tbKnot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbKnot.TextChanged += new System.EventHandler(this.tbKnot_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(13, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "km / hod:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(13, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "knot:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 188);
            this.Controls.Add(this.tbKMH);
            this.Controls.Add(this.tbKnot);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbMpg);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbLna100km);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbFahr);
            this.Controls.Add(this.tbCels);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Převody jednotek";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbCels;
        private System.Windows.Forms.TextBox tbFahr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbLna100km;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbMpg;
        private System.Windows.Forms.TextBox tbKMH;
        private System.Windows.Forms.TextBox tbKnot;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

