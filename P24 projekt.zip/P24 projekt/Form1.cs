﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsComboBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Sinus");
            comboBox1.Items.Add("Cosinus");
            comboBox1.Items.Add("Tangens");
            comboBox1.Items.Add("log 10");
            comboBox1.Items.Add("ln");
            comboBox1.Items.Add("10 na X");
            comboBox1.Items.Add("e na X");
            comboBox1.Items.Add("faktorial");
            for (int i = 0; i < 91; i++)
            {
                comboBox2.Items.Add(i.ToString());
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int op; string operace;
            op = comboBox1.SelectedIndex;
            operace = comboBox1.Items[op].ToString();
            textBox1.Text = "";
            textBox1.Text = operace;
        }

        private double Vysledek()
        {
            int op,pp; double v;
            op = comboBox1.SelectedIndex;
            pp = comboBox2.SelectedIndex;
            switch (op)
            {
                case 0: v = Math.Sin(pp * 3.14 / 180); break;
                case 1: v = Math.Cos(pp * 3.14 / 180); break;
                case 2: v = Math.Tan(pp * 3.14 / 180); break;
                default: v = 0; break;
 
            }
            return v;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int pp; string parametr;
            pp = comboBox2.SelectedIndex;
            parametr = comboBox2.Items[pp].ToString();
            textBox1.Text = textBox1.Text + " " + parametr + " = ";
            textBox1.Text = textBox1.Text + Vysledek().ToString("#0.000");
        }
    }
}
