﻿using System;

namespace ConsoleTrojuhelnik
{
    class Program
    {
        // funkce vrací true, pokud to může být trojúhelník anebo
        // navrací false pokud není splněna trojúhelníková nerovnost
        static bool MuzeBytTroj(int x, int y, int z)
        {
            bool vys = true;		// zavedeme si logickou proměnnou pro  
            // výsledek a nastavíme předpoklad, že může
            if ((x + y) < z || (x + z) < y || (y + z) < x)
                vys = false;
            // logický výraz může změnit výsledek na false
            return vys;	   // funkce navrací výslednou logickou hodnotu	
        }

        static void Main(string[] args)
        {
            int a, b, c;
            bool vysledek;
            Console.Write("Zadejte 3 hodnoty - delky stran: ");
            a = Convert.ToInt16(Console.ReadLine());
            b = Convert.ToInt16(Console.ReadLine());
            c = Convert.ToInt16(Console.ReadLine());
            // vyvoláme funkci a předáme 3 parametry hodnotou
            vysledek = MuzeBytTroj(a, b, c);
            Console.Write(vysledek ? "muze" : "nemuze");  // zobrazíme výsledek
            // použijeme podmíněný (ternární) operátor
            Console.Write(" to byt trojuhelnik");
            Console.ReadLine();
        }
    }
}

