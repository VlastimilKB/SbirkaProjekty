﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbvypocetobjemulitre = new System.Windows.Forms.TextBox();
            this.tbNosadnikov = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tbvypocetobjemu3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbzasobovanie = new System.Windows.Forms.TextBox();
            this.tBlitru = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tBzustatek = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(108, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Výpočet objemu m3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(368, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "N osadníkov";
            // 
            // tbvypocetobjemulitre
            // 
            this.tbvypocetobjemulitre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbvypocetobjemulitre.Location = new System.Drawing.Point(291, 124);
            this.tbvypocetobjemulitre.Name = "tbvypocetobjemulitre";
            this.tbvypocetobjemulitre.Size = new System.Drawing.Size(133, 26);
            this.tbvypocetobjemulitre.TabIndex = 5;
            this.tbvypocetobjemulitre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbNosadnikov
            // 
            this.tbNosadnikov.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbNosadnikov.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbNosadnikov.Location = new System.Drawing.Point(504, 34);
            this.tbNosadnikov.Name = "tbNosadnikov";
            this.tbNosadnikov.Size = new System.Drawing.Size(133, 26);
            this.tbNosadnikov.TabIndex = 6;
            this.tbNosadnikov.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(483, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(214, 67);
            this.button1.TabIndex = 8;
            this.button1.Text = "Výpočet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(108, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Výpočet objemu lit";
            // 
            // tbvypocetobjemu3
            // 
            this.tbvypocetobjemu3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbvypocetobjemu3.Location = new System.Drawing.Point(291, 163);
            this.tbvypocetobjemu3.Name = "tbvypocetobjemu3";
            this.tbvypocetobjemu3.Size = new System.Drawing.Size(133, 26);
            this.tbvypocetobjemu3.TabIndex = 10;
            this.tbvypocetobjemu3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(22, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "D v metrech";
            // 
            // tbD
            // 
            this.tbD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbD.Location = new System.Drawing.Point(205, 31);
            this.tbD.Name = "tbD";
            this.tbD.Size = new System.Drawing.Size(133, 26);
            this.tbD.TabIndex = 12;
            this.tbD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(108, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(197, 20);
            this.label4.TabIndex = 13;
            this.label4.Text = "Pocet zasobovacich dni\r\n";
            // 
            // tbzasobovanie
            // 
            this.tbzasobovanie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tbzasobovanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbzasobovanie.Location = new System.Drawing.Point(324, 211);
            this.tbzasobovanie.Name = "tbzasobovanie";
            this.tbzasobovanie.Size = new System.Drawing.Size(100, 26);
            this.tbzasobovanie.TabIndex = 14;
            this.tbzasobovanie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBlitru
            // 
            this.tBlitru.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tBlitru.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBlitru.Location = new System.Drawing.Point(537, 68);
            this.tBlitru.Name = "tBlitru";
            this.tBlitru.Size = new System.Drawing.Size(100, 26);
            this.tBlitru.TabIndex = 16;
            this.tBlitru.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(368, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "Litru / osoba / den";
            // 
            // tBzustatek
            // 
            this.tBzustatek.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tBzustatek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBzustatek.Location = new System.Drawing.Point(592, 213);
            this.tBzustatek.Name = "tBzustatek";
            this.tBzustatek.Size = new System.Drawing.Size(100, 26);
            this.tBzustatek.TabIndex = 18;
            this.tBzustatek.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(469, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 20);
            this.label7.TabIndex = 17;
            this.label7.Text = "Zůstatek litru:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 265);
            this.Controls.Add(this.tBzustatek);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tBlitru);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbzasobovanie);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbvypocetobjemu3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbNosadnikov);
            this.Controls.Add(this.tbvypocetobjemulitre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "KAPACITA VODOJEMU";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbvypocetobjemulitre;
        private System.Windows.Forms.TextBox tbNosadnikov;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbvypocetobjemu3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbzasobovanie;
        private System.Windows.Forms.TextBox tBlitru;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBzustatek;
        private System.Windows.Forms.Label label7;
    }
}

