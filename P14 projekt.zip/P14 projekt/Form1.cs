﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float D,r,objemlitre,objemm3,Nosadnikov,PocetDnu, zustatek;
            int pocdnu, LitruOsDen;
            D = Convert.ToSingle(tbD.Text);
            r = D / 2;
            objemm3 = (float) ((4* Math.PI * r * r * r)/3);
            objemlitre = objemm3 * 1000;
            tbvypocetobjemulitre.Text = objemlitre.ToString();
            tbvypocetobjemu3.Text = objemm3.ToString();
            LitruOsDen = Convert.ToInt16(tBlitru.Text);
            Nosadnikov = Convert.ToSingle(tbNosadnikov.Text);
            PocetDnu = objemlitre / LitruOsDen / Nosadnikov;
            pocdnu = (int)PocetDnu;
            tbzasobovanie.Text = pocdnu.ToString();
            zustatek = objemlitre - pocdnu * Nosadnikov * LitruOsDen;
            tBzustatek.Text = zustatek.ToString("#0");
                
        }
    }
}
