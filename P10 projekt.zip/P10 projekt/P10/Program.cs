﻿using System;

namespace ConsoleKomplex
{
    class komplexne_cislo	// definice třídy
    {
        private double realna_cast, imag_cast;
        private double R, Fi;

        public void UdelejPolSouradnice()
        {
            R = Math.Sqrt(realna_cast * realna_cast + imag_cast * 
                          imag_cast);
            Fi = 180*Math.Atan2(imag_cast, realna_cast)/Math.PI;
        }

        public double hR()
        {   return R; }

        public double hFi()
        {   return Fi; }

        public komplexne_cislo(double R, double I)         // konstruktor 1
        {   realna_cast = R; imag_cast = I; }

        public komplexne_cislo(double R)                   // konstruktor 2
        {   realna_cast = R; imag_cast = 0; }

        public komplexne_cislo(int I)                      // konstruktor 3
        {   realna_cast = 0; imag_cast = I; }
                                                                                         
                                                     // pretizeni operatoru
        public static komplexne_cislo operator +(komplexne_cislo c1, 
                                                 komplexne_cislo c2)
        {   return new komplexne_cislo(c1.realna_cast + c2.realna_cast, 
                                       c1.imag_cast + c2.imag_cast); 
        }

        public static komplexne_cislo operator -(komplexne_cislo c1, 
                                                 komplexne_cislo c2)
        {   return new komplexne_cislo(c1.realna_cast - c2.realna_cast, 
                                       c1.imag_cast - c2.imag_cast); 
        }

        public static komplexne_cislo operator *(komplexne_cislo c1, 
                                                 komplexne_cislo c2)
        {
            return new komplexne_cislo(c1.realna_cast * c2.realna_cast - c1.imag_cast * c2.imag_cast, c1.realna_cast*c2.imag_cast+ c2.realna_cast*c1.imag_cast);
        }

        public static komplexne_cislo operator /(komplexne_cislo c1, 
                                                 komplexne_cislo c2)
        {
            double p = c2.realna_cast * c2.realna_cast + c2.imag_cast * 
                       c2.imag_cast;
            return new komplexne_cislo(((c1.realna_cast * c2.realna_cast) + (c1.imag_cast * c2.imag_cast))/p,(c1.imag_cast*c2.realna_cast-c1.realna_cast*c2.imag_cast)/p);
        }
        
        public double rc()
        {   return realna_cast; }

        public double ic()
        {   return imag_cast; }

        public double Modul()
        {   return Math.Sqrt(realna_cast * realna_cast + imag_cast * 
                             imag_cast); }

        public void nastav_hodnotu(double x, double y)
        {   realna_cast = x; imag_cast = y; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            komplexne_cislo a = new komplexne_cislo(6.0,11.0);
            komplexne_cislo b = new komplexne_cislo(3.0,5.0);
            komplexne_cislo v = new komplexne_cislo(0, 0);
                        
            v = a*b;
            Console.Write("A: " + a.rc().ToString("##0.##0"));
            Console.WriteLine(" + " + a.ic().ToString("##0.##0")+"i");
            Console.Write("B: " + b.rc().ToString("##0.##0"));
            Console.WriteLine(" + " + b.ic().ToString("##0.##0") + "i");
            Console.WriteLine();
            Console.WriteLine("Soucin:");
            Console.Write("Vysledek: " + v.rc().ToString("##0.##0"));
            Console.WriteLine(" + " + v.ic().ToString("##0.##0")+"i");
            v.UdelejPolSouradnice();
            Console.WriteLine(" R: " + v.hR().ToString("##0.##0"));
            Console.WriteLine("Fi: " + v.hFi().ToString("##0.##0")+" stupnu");

            v = a / b;
            Console.WriteLine();
            Console.WriteLine("Podil:");
            Console.Write("Vysledek: " + v.rc().ToString("##0.##0"));
            Console.WriteLine(" + " + v.ic().ToString("##0.##0") + "i");
            v.UdelejPolSouradnice();
            Console.WriteLine(" R: " + v.hR().ToString("##0.##0"));
            Console.WriteLine("Fi: " + v.hFi().ToString("##0.##0") + " stupnu");

            Console.ReadLine();
        }
    }
}

