﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Bitmap KresliciOblast;
        private Pen MojeTuzka;

        private void InicKresliciOblasti()
        {
            Graphics Pozadi;
            MojeTuzka = new Pen(Color.LightYellow);
            Pozadi = Graphics.FromImage(KresliciOblast);
            for (int x = 0; x < this.Width; x++)
                Pozadi.DrawLine(MojeTuzka, x, 0, x, this.Height);       // vycarujeme si barvou pozadi
            Pozadi.Dispose();
            this.Invalidate();
        }
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)     // this odkazuje na sebe sama tedy Form1
        {
            KresliciOblast = new Bitmap(this.ClientRectangle.Width, this.ClientRectangle.Height, 
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            InicKresliciOblasti();                       // nachystame si pozadi nejakou vybranou barvou
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics Kresba;
            Kresba = e.Graphics;
            Kresba.DrawImage(KresliciOblast, 0, 0, KresliciOblast.Width, KresliciOblast.Height);
            Kresba.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)          // OBRAZKY NA FORMULARI
        {
            Graphics Kresba;
            Kresba = Graphics.FromImage(KresliciOblast);
            Image Obrazek = Image.FromFile("focus.JPG");       // soubor bez cesty je v bin-debug
            GraphicsUnit jednotka = GraphicsUnit.Pixel;
                                                                        // cely 
            Rectangle Obdelnik1 = new Rectangle(20,20,1180,660);         // obdelnik pro vepsani obrazku
            float x = 0.0F; float y = 0.0F;
            float sirka = 580.0F; float vyska = 320.0F;                 // SKUTECNY ROZMER
            Kresba.DrawImage(Obrazek, Obdelnik1, x,y,sirka,vyska, jednotka);

                                                                        // leva horni cast
           /* Rectangle Obdelnik2 = new Rectangle(50, 50, 200, 150);
            x = 0.0F; y = 0.0F;
            sirka = 400.0F; vyska = 300.0F;
            Kresba.DrawImage(Obrazek, Obdelnik2, x, y, sirka, vyska, jednotka);
                                                                        // prava horni cast
            Rectangle Obdelnik3 = new Rectangle(255, 50, 200, 150);
            x = 400.0F; y = 0.0F;
            sirka = 400.0F; vyska = 300.0F;
            Kresba.DrawImage(Obrazek, Obdelnik3, x, y, sirka, vyska, jednotka);
                                                                        // leva dolni cast
            Rectangle Obdelnik4 = new Rectangle(50, 205, 200, 150);
            x = 0.0F; y = 300.0F;
            sirka = 400.0F; vyska = 300.0F;
            Kresba.DrawImage(Obrazek, Obdelnik4, x, y, sirka, vyska, jednotka);
                                                                        // prava dolni cast
            Rectangle Obdelnik5 = new Rectangle(255, 205, 200, 150);
            x = 400.0F; y = 300.0F;
            sirka = 400.0F; vyska = 300.0F;
            Kresba.DrawImage(Obrazek, Obdelnik5, x, y, sirka, vyska, jednotka);*/
            
            Kresba.Dispose();
            this.Invalidate();


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }
    }
}
