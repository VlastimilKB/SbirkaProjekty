﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Bitmap KresliciOblast;
        private Pen MojeTuzka;

        private void InicKresliciOblasti()
        {
            Graphics Pozadi;
            MojeTuzka = new Pen(Color.LightYellow);
            Pozadi = Graphics.FromImage(KresliciOblast);
            for (int x = 0; x < this.Width; x++)
                Pozadi.DrawLine(MojeTuzka, x, 0, x, this.Height);       // vycarujeme si barvou pozadi
            Pozadi.Dispose();
            this.Invalidate();
        }
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)     // this odkazuje na sebe sama tedy Form1
        {
            KresliciOblast = new Bitmap(this.ClientRectangle.Width, this.ClientRectangle.Height, 
                System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            InicKresliciOblasti();                       // nachystame si pozadi nejakou vybranou barvou
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics Kresba;
            Kresba = e.Graphics;
            Kresba.DrawImage(KresliciOblast, 0, 0, KresliciOblast.Width, KresliciOblast.Height);
            Kresba.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)          // OBRAZKY NA FORMULARI
        {
            Graphics Kresba;
            Kresba = Graphics.FromImage(KresliciOblast);
            try
            {
                Image Obrazek = Image.FromFile("focus.JPG");       // soubor bez cesty je v bin-debug
            }
            catch
            {
                MessageBox.Show("Obrazek nenalezen!");
                return;
            }
            GraphicsUnit jednotka = GraphicsUnit.Pixel;
                                                                     // cely 
            Rectangle Obdelnik1 = new Rectangle(20,60,1180,660);         // obdelnik pro vepsani obrazku
            float x = 0.0F; float y = 0.0F;
            float sirka = 580.0F; float vyska = 320.0F;                 // SKUTECNY ROZMER
            Image Obrazek2 = Image.FromFile("focus.JPG");
            Kresba.DrawImage(Obrazek2, Obdelnik1, x,y,sirka,vyska, jednotka);

           /*                                                             // leva horni cast
            Rectangle Obdelnik2 = new Rectangle(20, 60, 590, 320);
            float sirka, vyska, x, y;
            sirka = 290.0F; vyska = 160.0F;
            x = 0.0F; y = 0.0F;
            Image Obrazek2 = Image.FromFile("focus.JPG");
            Kresba.DrawImage(Obrazek2, Obdelnik2, x, y, sirka, vyska, jednotka);
                                                                        // prava horni cast
            Rectangle Obdelnik3 = new Rectangle(615, 60, 590, 320);
            x = 290.0F; y = 0.0F;
            sirka = 290.0F; vyska = 160.0F;
            Kresba.DrawImage(Obrazek2, Obdelnik3, x, y, sirka, vyska, jednotka);*/
            
            Kresba.Dispose();
            this.Invalidate();
        }
    }
}
