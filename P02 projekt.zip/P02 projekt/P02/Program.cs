﻿

using System;

namespace ConsoleSoucet1azN       // aplikace pro vypocet souctu 1 až N
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, soucet = 0;			// deklarace proměnných
            Console.Write("zadej N:");	// vstup čísla z konzole
            n = Convert.ToInt16(Console.ReadLine());  // převod řetězce na 
            // 16 bitové číslo typu int
            for (int i = 1; i <= n; i++)		// cyklus for postupně nastavuje                          
                // proměnnou i na hodnoty 1,2,3,…,n
                soucet += i;	    // přičtení aktuální hodnoty i do soucet
            // stejný význam jako soucet = soucet + i
            Console.WriteLine("soucet 1 až " + n + " je " + soucet);
            // vypis vysledku
            Console.ReadLine();		// čekáme na Enter, aby neutekla 
            // obrazovka s vysledkem zpět do editoru integrovaného prostředí
        }
    }
}


