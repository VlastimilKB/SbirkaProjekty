﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void naDruhouToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup, vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na druhou";
        }

        private void naTřetíToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup, vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = vstup * vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na třetí";
        }

        private void sinusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup;
            double vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = Math.Sin((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "sinus";
        }

        private void odmocninaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup;
            double vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = Math.Sqrt((double)vstup);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "Odmocnina";
        }

        private void tangensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup;
            double vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = Math.Tan((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "tangens";
        }

        private void cosinusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup;
            double vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = Math.Cos((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "cosinus";
        }

        private void xNa4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup, vysledek;
            vstup = Convert.ToInt16(tbVstup.Text);
            vysledek = vstup * vstup * vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na čtvrtou";
        }

        private void faktoriálToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int vstup;
            double f = 1.0;
            vstup = Convert.ToInt16(tbVstup.Text);
            for (int i = 2; i <= vstup; i++)
                f *= i;
            tbVysledek.Text = f.ToString();
            lbOperace.Text = "Faktorial";
        }
    }
}
