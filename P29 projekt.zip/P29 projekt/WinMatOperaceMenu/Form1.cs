﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void naDruhouToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, vysledek, c;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na druhou";
        }

        private void naTřetíToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, vysledek, c;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = vstup * vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na třetí";
        }

        private void sinusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, c;
            double vysledek;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = Math.Sin((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "sinus";
        }

        private void odmocninaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, c;
            double vysledek;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = Math.Sqrt((double)vstup);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "Odmocnina";
        }

        private void tangensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, c;
            double vysledek;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = Math.Tan((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "tangens";
        }

        private void cosinusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, c;
            double vysledek;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = Math.Cos((double)vstup * Math.PI / 180);
            tbVysledek.Text = vysledek.ToString("0.000");
            lbOperace.Text = "cosinus";
        }

        private void xNa4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, vysledek, c;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            vysledek = vstup * vstup * vstup * vstup;
            tbVysledek.Text = vysledek.ToString("0.00");
            lbOperace.Text = "Na čtvrtou";
        }

        private void faktoriálToolStripMenuItem_Click(object sender, EventArgs e)
        {
            float vstup, c;
            int n;
            if (float.TryParse(tbVstup.Text, out c))
                vstup = c;     // TextBox obsahuje platné číslo
            else
            {
                MessageBox.Show("Zadej platné číslo!");
                return;
            }
            double f = 1.0;
            n = (int)vstup;
            if(n<2){
                tbVysledek.Text = f.ToString();
                lbOperace.Text = "Faktorial";
                return;
            }
            for (int i = 2; i <= n; i++)
                f *= i;
            tbVysledek.Text = f.ToString();
            lbOperace.Text = "Faktorial";
            tbVstup.Text = n.ToString();    // opravíme na přirozené číslo
        }
    }
}
