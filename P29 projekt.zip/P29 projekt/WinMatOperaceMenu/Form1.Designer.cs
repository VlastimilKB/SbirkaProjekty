﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbVstup = new System.Windows.Forms.TextBox();
            this.tbVysledek = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.matematikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.naDruhouToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.naTřetíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.odmocninaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goniometrieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cosinusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tangensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbOperace = new System.Windows.Forms.Label();
            this.dalsiOperaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xNa4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faktoriálToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(39, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vstup";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(211, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Vysledek";
            // 
            // tbVstup
            // 
            this.tbVstup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbVstup.Location = new System.Drawing.Point(12, 102);
            this.tbVstup.Name = "tbVstup";
            this.tbVstup.Size = new System.Drawing.Size(93, 26);
            this.tbVstup.TabIndex = 2;
            this.tbVstup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbVysledek
            // 
            this.tbVysledek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbVysledek.Location = new System.Drawing.Point(214, 102);
            this.tbVysledek.Name = "tbVysledek";
            this.tbVysledek.Size = new System.Drawing.Size(205, 26);
            this.tbVysledek.TabIndex = 3;
            this.tbVysledek.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matematikaToolStripMenuItem,
            this.goniometrieToolStripMenuItem,
            this.dalsiOperaceToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(449, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // matematikaToolStripMenuItem
            // 
            this.matematikaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.naDruhouToolStripMenuItem,
            this.naTřetíToolStripMenuItem,
            this.odmocninaToolStripMenuItem});
            this.matematikaToolStripMenuItem.Name = "matematikaToolStripMenuItem";
            this.matematikaToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.matematikaToolStripMenuItem.Text = "Matematika";
            // 
            // naDruhouToolStripMenuItem
            // 
            this.naDruhouToolStripMenuItem.Name = "naDruhouToolStripMenuItem";
            this.naDruhouToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.naDruhouToolStripMenuItem.Text = "na druhou";
            this.naDruhouToolStripMenuItem.Click += new System.EventHandler(this.naDruhouToolStripMenuItem_Click);
            // 
            // naTřetíToolStripMenuItem
            // 
            this.naTřetíToolStripMenuItem.Name = "naTřetíToolStripMenuItem";
            this.naTřetíToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.naTřetíToolStripMenuItem.Text = "na třetí";
            this.naTřetíToolStripMenuItem.Click += new System.EventHandler(this.naTřetíToolStripMenuItem_Click);
            // 
            // odmocninaToolStripMenuItem
            // 
            this.odmocninaToolStripMenuItem.Name = "odmocninaToolStripMenuItem";
            this.odmocninaToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.odmocninaToolStripMenuItem.Text = "odmocnina";
            this.odmocninaToolStripMenuItem.Click += new System.EventHandler(this.odmocninaToolStripMenuItem_Click);
            // 
            // goniometrieToolStripMenuItem
            // 
            this.goniometrieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sinusToolStripMenuItem,
            this.cosinusToolStripMenuItem,
            this.tangensToolStripMenuItem});
            this.goniometrieToolStripMenuItem.Name = "goniometrieToolStripMenuItem";
            this.goniometrieToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.goniometrieToolStripMenuItem.Text = "Goniometrie";
            // 
            // sinusToolStripMenuItem
            // 
            this.sinusToolStripMenuItem.Name = "sinusToolStripMenuItem";
            this.sinusToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sinusToolStripMenuItem.Text = "sinus";
            this.sinusToolStripMenuItem.Click += new System.EventHandler(this.sinusToolStripMenuItem_Click);
            // 
            // cosinusToolStripMenuItem
            // 
            this.cosinusToolStripMenuItem.Name = "cosinusToolStripMenuItem";
            this.cosinusToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cosinusToolStripMenuItem.Text = "cosinus";
            this.cosinusToolStripMenuItem.Click += new System.EventHandler(this.cosinusToolStripMenuItem_Click);
            // 
            // tangensToolStripMenuItem
            // 
            this.tangensToolStripMenuItem.Name = "tangensToolStripMenuItem";
            this.tangensToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.tangensToolStripMenuItem.Text = "tangens";
            this.tangensToolStripMenuItem.Click += new System.EventHandler(this.tangensToolStripMenuItem_Click);
            // 
            // lbOperace
            // 
            this.lbOperace.AutoSize = true;
            this.lbOperace.Location = new System.Drawing.Point(120, 110);
            this.lbOperace.Name = "lbOperace";
            this.lbOperace.Size = new System.Drawing.Size(73, 13);
            this.lbOperace.TabIndex = 5;
            this.lbOperace.Text = "bude operace";
            // 
            // dalsiOperaceToolStripMenuItem
            // 
            this.dalsiOperaceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xNa4ToolStripMenuItem,
            this.faktoriálToolStripMenuItem});
            this.dalsiOperaceToolStripMenuItem.Name = "dalsiOperaceToolStripMenuItem";
            this.dalsiOperaceToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.dalsiOperaceToolStripMenuItem.Text = "dalsi operace";
            // 
            // xNa4ToolStripMenuItem
            // 
            this.xNa4ToolStripMenuItem.Name = "xNa4ToolStripMenuItem";
            this.xNa4ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.xNa4ToolStripMenuItem.Text = "x na 4";
            this.xNa4ToolStripMenuItem.Click += new System.EventHandler(this.xNa4ToolStripMenuItem_Click);
            // 
            // faktoriálToolStripMenuItem
            // 
            this.faktoriálToolStripMenuItem.Name = "faktoriálToolStripMenuItem";
            this.faktoriálToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.faktoriálToolStripMenuItem.Text = "faktoriál";
            this.faktoriálToolStripMenuItem.Click += new System.EventHandler(this.faktoriálToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 261);
            this.Controls.Add(this.lbOperace);
            this.Controls.Add(this.tbVysledek);
            this.Controls.Add(this.tbVstup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Matematicke operace";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbVstup;
        private System.Windows.Forms.TextBox tbVysledek;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem matematikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem naDruhouToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem naTřetíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem odmocninaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goniometrieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cosinusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tangensToolStripMenuItem;
        private System.Windows.Forms.Label lbOperace;
        private System.Windows.Forms.ToolStripMenuItem dalsiOperaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xNa4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faktoriálToolStripMenuItem;
    }
}

