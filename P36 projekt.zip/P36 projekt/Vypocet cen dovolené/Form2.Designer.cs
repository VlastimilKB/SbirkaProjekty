﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tBcedok1t = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tBcedoklm = new System.Windows.Forms.TextBox();
            this.tBfisher1t = new System.Windows.Forms.TextBox();
            this.tBfisherlm = new System.Windows.Forms.TextBox();
            this.tBtourbus1t = new System.Windows.Forms.TextBox();
            this.tbtourbuslm = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cestovní kancelář";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(218, 175);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "zavřít";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tBcedok1t
            // 
            this.tBcedok1t.Location = new System.Drawing.Point(159, 76);
            this.tBcedok1t.Name = "tBcedok1t";
            this.tBcedok1t.Size = new System.Drawing.Size(72, 20);
            this.tBcedok1t.TabIndex = 2;
            this.tBcedok1t.Text = "11390";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(156, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Cena za 1 týden";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(253, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "% sleva na last minute";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Čedok";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Fisher";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(79, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Tour Bus";
            // 
            // tBcedoklm
            // 
            this.tBcedoklm.Location = new System.Drawing.Point(276, 79);
            this.tBcedoklm.Name = "tBcedoklm";
            this.tBcedoklm.Size = new System.Drawing.Size(72, 20);
            this.tBcedoklm.TabIndex = 8;
            this.tBcedoklm.Text = "25";
            // 
            // tBfisher1t
            // 
            this.tBfisher1t.Location = new System.Drawing.Point(159, 106);
            this.tBfisher1t.Name = "tBfisher1t";
            this.tBfisher1t.Size = new System.Drawing.Size(72, 20);
            this.tBfisher1t.TabIndex = 9;
            this.tBfisher1t.Text = "13790";
            // 
            // tBfisherlm
            // 
            this.tBfisherlm.Location = new System.Drawing.Point(276, 109);
            this.tBfisherlm.Name = "tBfisherlm";
            this.tBfisherlm.Size = new System.Drawing.Size(72, 20);
            this.tBfisherlm.TabIndex = 10;
            this.tBfisherlm.Text = "15";
            // 
            // tBtourbus1t
            // 
            this.tBtourbus1t.Location = new System.Drawing.Point(159, 134);
            this.tBtourbus1t.Name = "tBtourbus1t";
            this.tBtourbus1t.Size = new System.Drawing.Size(72, 20);
            this.tBtourbus1t.TabIndex = 11;
            this.tBtourbus1t.Text = "10990";
            // 
            // tbtourbuslm
            // 
            this.tbtourbuslm.Location = new System.Drawing.Point(276, 137);
            this.tbtourbuslm.Name = "tbtourbuslm";
            this.tbtourbuslm.Size = new System.Drawing.Size(72, 20);
            this.tbtourbuslm.TabIndex = 12;
            this.tbtourbuslm.Text = "30";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 261);
            this.Controls.Add(this.tbtourbuslm);
            this.Controls.Add(this.tBtourbus1t);
            this.Controls.Add(this.tBfisherlm);
            this.Controls.Add(this.tBfisher1t);
            this.Controls.Add(this.tBcedoklm);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tBcedok1t);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Cenik vsech moznosti";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox tBcedok1t;
        public System.Windows.Forms.TextBox tBcedoklm;
        public System.Windows.Forms.TextBox tBfisher1t;
        public System.Windows.Forms.TextBox tBfisherlm;
        public System.Windows.Forms.TextBox tBtourbus1t;
        public System.Windows.Forms.TextBox tbtourbuslm;
    }
}