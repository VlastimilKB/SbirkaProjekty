﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rBtourbus = new System.Windows.Forms.RadioButton();
            this.rBfisher = new System.Windows.Forms.RadioButton();
            this.rBcedok = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.tBpocetosob = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cBlm = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBcelkovacena = new System.Windows.Forms.TextBox();
            this.tBtydny = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tBtydny)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rBtourbus);
            this.groupBox1.Controls.Add(this.rBfisher);
            this.groupBox1.Controls.Add(this.rBcedok);
            this.groupBox1.Location = new System.Drawing.Point(8, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 103);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cestovní kancelář";
            // 
            // rBtourbus
            // 
            this.rBtourbus.AutoSize = true;
            this.rBtourbus.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.rBtourbus.Location = new System.Drawing.Point(7, 73);
            this.rBtourbus.Name = "rBtourbus";
            this.rBtourbus.Size = new System.Drawing.Size(68, 17);
            this.rBtourbus.TabIndex = 2;
            this.rBtourbus.Text = "Tour Bus";
            this.rBtourbus.UseVisualStyleBackColor = true;
            this.rBtourbus.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // rBfisher
            // 
            this.rBfisher.AutoSize = true;
            this.rBfisher.Location = new System.Drawing.Point(7, 50);
            this.rBfisher.Name = "rBfisher";
            this.rBfisher.Size = new System.Drawing.Size(53, 17);
            this.rBfisher.TabIndex = 1;
            this.rBfisher.TabStop = true;
            this.rBfisher.Text = "Fisher";
            this.rBfisher.UseVisualStyleBackColor = true;
            // 
            // rBcedok
            // 
            this.rBcedok.AutoSize = true;
            this.rBcedok.Checked = true;
            this.rBcedok.Location = new System.Drawing.Point(7, 27);
            this.rBcedok.Name = "rBcedok";
            this.rBcedok.Size = new System.Drawing.Size(56, 17);
            this.rBcedok.TabIndex = 0;
            this.rBcedok.TabStop = true;
            this.rBcedok.Text = "Čedok";
            this.rBcedok.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(166, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Počet osob";
            // 
            // tBpocetosob
            // 
            this.tBpocetosob.Location = new System.Drawing.Point(233, 13);
            this.tBpocetosob.Name = "tBpocetosob";
            this.tBpocetosob.Size = new System.Drawing.Size(19, 20);
            this.tBpocetosob.TabIndex = 2;
            this.tBpocetosob.Text = "2";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(166, 56);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 46);
            this.button1.TabIndex = 3;
            this.button1.Text = "ceník za 1 týden";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(257, 56);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 46);
            this.button2.TabIndex = 4;
            this.button2.Text = "Výpočet ceny";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(257, 198);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(85, 29);
            this.button3.TabIndex = 5;
            this.button3.Text = "Konec";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Počet týdnů pobnytu";
            // 
            // cBlm
            // 
            this.cBlm.AutoSize = true;
            this.cBlm.Location = new System.Drawing.Point(272, 16);
            this.cBlm.Name = "cBlm";
            this.cBlm.Size = new System.Drawing.Size(80, 17);
            this.cBlm.TabIndex = 7;
            this.cBlm.Text = "Last minute";
            this.cBlm.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(179, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Celková cena";
            // 
            // tBcelkovacena
            // 
            this.tBcelkovacena.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBcelkovacena.Location = new System.Drawing.Point(262, 133);
            this.tBcelkovacena.Name = "tBcelkovacena";
            this.tBcelkovacena.Size = new System.Drawing.Size(80, 24);
            this.tBcelkovacena.TabIndex = 9;
            this.tBcelkovacena.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBtydny
            // 
            this.tBtydny.Location = new System.Drawing.Point(18, 156);
            this.tBtydny.Maximum = 4;
            this.tBtydny.Minimum = 1;
            this.tBtydny.Name = "tBtydny";
            this.tBtydny.Size = new System.Drawing.Size(148, 45);
            this.tBtydny.TabIndex = 10;
            this.tBtydny.Value = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "1            2            3            4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 240);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tBtydny);
            this.Controls.Add(this.tBcelkovacena);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cBlm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tBpocetosob);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Vypocet ceny za dovolenou";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tBtydny)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rBtourbus;
        private System.Windows.Forms.RadioButton rBfisher;
        private System.Windows.Forms.RadioButton rBcedok;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBpocetosob;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cBlm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBcelkovacena;
        private System.Windows.Forms.TrackBar tBtydny;
        private System.Windows.Forms.Label label4;
    }
}

