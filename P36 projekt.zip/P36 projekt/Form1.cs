﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form2 InstanceForm2 = new Form2();
        static float CenaCelkem = 0.0f;
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InstanceForm2.Owner = this;
            InstanceForm2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float cenat = 0.0f;
            int pocetosob, pocettydnu;
            ///////////////////////// Check na cestovku ///////////////////
            if (rBcedok.Checked)
            {
                if (cBlm.Checked)
                {
                    cenat = (1 - (Convert.ToSingle(InstanceForm2.tBcedoklm.Text) / 100)) * Convert.ToSingle(InstanceForm2.tBcedok1t.Text);
                }
                else
                    cenat = Convert.ToSingle(InstanceForm2.tBcedok1t.Text);
            }
            if (rBfisher.Checked)
            {
                if (cBlm.Checked)
                {
                    cenat = (1 - (Convert.ToSingle(InstanceForm2.tBfisherlm.Text) / 100)) * Convert.ToSingle(InstanceForm2.tBfisher1t.Text);
                }
                else
                    cenat = Convert.ToSingle(InstanceForm2.tBfisher1t.Text);
            }
            if (rBtourbus.Checked)
            {
                if (cBlm.Checked)
                {
                    cenat = (1 - (Convert.ToSingle(InstanceForm2.tbtourbuslm.Text) / 100)) * Convert.ToSingle(InstanceForm2.tBtourbus1t.Text);
                }
                else
                    cenat = Convert.ToSingle(InstanceForm2.tBtourbus1t.Text);
            }
            ///////////////////////////////////////////////////////////////
            pocetosob = Convert.ToInt16(tBpocetosob.Text);
            ///////////////////////////////////////////////////////////////
            pocettydnu = tBtydny.Value;
            ///////////////////////////////////////////////////////////////


            CenaCelkem = cenat * pocetosob * pocettydnu;
            tBcelkovacena.Text = CenaCelkem.ToString() + " Kč";
        }
    }
}
