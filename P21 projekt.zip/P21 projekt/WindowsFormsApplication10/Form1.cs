﻿using System;
using System.IO;                        // doplnit tento radek
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs eVe)
        {
            try
            {
                StreamWriter sw = new StreamWriter("TextFile.txt");
                sw.Write("It is the first ");
                sw.WriteLine("line of file.");
                sw.Write("Date and times:");
                sw.WriteLine(DateTime.Now);  
                sw.Close();
            }
            catch (Exception e)                          // hlaseni pri zachycene vyjimce
            {
                MessageBox.Show("Nebylo možné zapsat do souboru :" + e.Message);
            }
        }

        private void button2_Click(object sender, EventArgs eVe)
        {
           try
            {
                StreamReader sr = new StreamReader("TextFile.txt");        
                String radek;
                int Pocetradku = 0;
                int PocZnaku = 0;
                while ((radek = sr.ReadLine()) != null)
                {
                    richTextBox1.Text += radek;
                    richTextBox1.Text += "\n";
                    Pocetradku++;
                    PocZnaku +=  radek.Length;
                }
                sr.Close();
               tBPocetradku.Text=Pocetradku.ToString();
               tBPocetznaku.Text = PocZnaku.ToString();
            }
            catch (Exception e)                             // hlaseni pri zachycene vyjimce
            {
                MessageBox.Show("Nebylo možné číst ze souboru :"+e.Message);
            }
        }

        private void button3_Click(object sender, EventArgs eVen)
        {
            const string FILE_NAME = "TextFile.txt";
            try
            {
                if (File.Exists(FILE_NAME))
                {
                    StreamWriter swr = File.AppendText(FILE_NAME);  // soubor otevren pro doplnovani radku
                    swr.WriteLine(textBox1.Text);
                    swr.Close();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Nebylo možné doplnit soubor :" + e.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }
    }
}
