﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double hodnota;
            hodnota = Convert.ToDouble(tbHodnota.Text);
            lbHodnoty.Items.Add(hodnota.ToString());
            tbPrumer.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double prumer, soucet=0;
            int pocethodnot;
            pocethodnot = lbHodnoty.Items.Count;
            if (pocethodnot == 0)
            {
                MessageBox.Show("Seznam hodnot je prázdný!");
                return;
            }                        
            
            for (int i = 0; i < pocethodnot; i++)
                soucet += Convert.ToDouble(lbHodnoty.Items[i].ToString());
            prumer = soucet / pocethodnot;
            tbPrumer.Text = prumer.ToString("#.##");
        }
    }
}
