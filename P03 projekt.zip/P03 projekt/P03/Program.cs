﻿using System;

namespace ConsoleMatOperace
{
    class Program
    {
        static int Secti(int p1, int p2)		// funkce pro soucet 
                                               // 2 hodnot typu int
        {
            return p1 + p2;		      // prikaz return navrací výsledek 
                                    // uvedeného typu funkce, zde tedy int
        }

        static int Soucin(int p1, int p2) 	// funkce pro soucin 
                                               // 2 hodnot typu int
        {
            return p1 * p2;  		// prikaz return navrací výsledek
        }

        static float Podil(int a, int b)		// funkce je typu float pro 
        // podíl 2 hodnot typu int, protože podíl může mít desetinna cisla
        {
            if (b != 0)				// pokud je b ruzne od nuly
                return (float)a / b;	// tak vracím výsledek a/b
            // (float) před výrazem je tzv. casting, změna typu hodnoty
            // pokud bych použil pouze a / b tak by se odsekla des.část
            else
                return 99999.999f;		// indikace chyby, pokud by došlo 
                                         // k dělení nulou
        }

        static int SoucetCtvercu(int x, int y)  // funkce pro součet čtverců
        {
            return x*x + y*y;		// prikaz return navrací výsledek
        }

        static int Rozdil(int p1, int p2)  	// funkce pro rozdil 
                                               // 2 hodnot typu int
        {
            return p1 - p2;		// prikaz return navrací výsledek
        }

        static float Prepona(int a, int b)      // funkce pro výpočet délky
                 // přepony pravoúhlého trojúhelníka o délkách odvěsen a, b
        {
            return (float)Math.Sqrt(a*a+b*b);
          // Math je knihovna (objekt) mnoha matemat. funkcí, zde použijeme
	    // funkci Sqrt, což je druhá odmocnina (square root) z parametru
    // funkce navrací implicitně hodnotu typu double, převedeme opet 
    // castingem (float) na hodnotu typu float
        }

        static float UhelVeStupnich(int a, int b)	// uhel ve stupnich
		            // pro pravoúhlý trojúhelník mezi stranami b a a
        {
            float uhel;		       // desetinné číslo pro výsledný úhel
            uhel =(float)(Math.Atan2((double)b,(double)a)*180/3.141592653);
// funkce požaduje parametry typu double, proto casting     
// funkce vrací hodnotu v radiánech, proto provedeme 
// přepočet z radiánů na stupně
            return uhel;
        }

        static float SinACosB(int a, int b)	// funkce navrací hodnotu
                                               // Sinus a + Cosinus b
        {
            float v;			            // proměnná pro výsledek
            v=(float)Math.Sin(a*3.141592653/180)+
              (float)Math.Cos(b*3.141592653/180);
// funkce sin a cos požadují parametry v radiánech, proto 
// musíme opět udělat přepočet ze stupňů na radiány
// a protože implicitně navrací double, tak casting na float
            return v;
        }

        static double faktorial(int a)	 // funkce pro výpočet faktoriálu
               // funkce je typu double, protože výsledky jsou velká čísla
        {
            double v = 1;	// proměnná pro výsledek, začíná hodnotou 1 
            for(int i=2; i<=a; i++)		// cyklus for postupně nastavuje // parametr i na 2,3,4,…, a
                v *= i;		            // výraz ve významu: v = v * i
            return v;		            // prikaz return navrací výsledek 
        }

        static double nnk(int a, int b)	// funkce navrací hodnotu 
                                         // kombinačního čísla n nad k
        {
            double v;
            v = faktorial(a) / faktorial(b) / faktorial(a-b);
			                       // výsledek je f(a)/(f(b)*f(a-b))
            return v;				// prikaz return navrací výsledek
        }

        static void Main(string[] args)	// funkce Main startuje aplikaci
        {
            int a, b, c;	// deklarujeme nezbytné proměnné typu int
            float p;		//    typu float
            double f, NnadK; //    typu double
            Console.Write("Zadej A:");	// vypíšeme výzvu k zadání hodnot
            a = Convert.ToInt16(Console.ReadLine());	   // převedeme zadaný 
                          // řetězec na hodnotu 16 bitového čísla typu int
            Console.Write("Zadej B:");
            b = Convert.ToInt16(Console.ReadLine());
		    // postupně voláme připravené funkce a zobrazujeme výsledky
            Console.WriteLine("Přepona je "+Prepona(a,b));
            Console.WriteLine("Uhel b/a je " + UhelVeStupnich(a,b)+" stupnu");
            c = SoucetCtvercu(a, b);
            Console.WriteLine("Součet čtverců je "+c);
            c = Secti(a, b);
            Console.WriteLine("Součet je " + c);
            c = Soucin(a, b);
            Console.WriteLine("Součin je " + c);
            p = Podil(a, b);
            Console.WriteLine("Podil je " + p);
            c = Rozdil(a, b);
            Console.WriteLine("Rozdil je " + c);
            p = SinACosB(a,b);
            Console.WriteLine("Sin A + Cos B je " + p);

            f=faktorial(a);
            Console.WriteLine("faktorial " + a + " je " + f);

            NnadK=nnk(a,b);
            Console.WriteLine("kombinaci " + a + " nad " + b + " je " + 
                               NnadK);

            Console.ReadLine();    // čekáme na klávesu Enter, aby neutekla 
      // obrazovka s výsledky do editoru integrovaného prostředí překladače
        }
    }
}


