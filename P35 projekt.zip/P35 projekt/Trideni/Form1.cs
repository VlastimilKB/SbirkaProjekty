﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int[] poleA = new int[20];
        public int[] poleB = new int[20];       // zalozni pole, aby bylo stejne pred tridenim

        private void button2_Click(object sender, EventArgs e)
        {
            Random G = new Random();
            string S = "";
            for (int i = 0; i < 20; i++)
            {
                poleA[i] = G.Next(100);
                poleB[i] = poleA[i];
                S += poleA[i].ToString()+" ";
            }
            tbPolePred.Text = S;
            tBBublPorovnani.Text = "";
            tBBublPrirazeni.Text = "";
            tBInsertPorovnani.Text = "";
            tBInsertPrirazeni.Text = "";
            tbPolePo.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)  // SORT BUBBLE
        {
            string S = "";
            long PocPri = 0, PocPor = 0;
            for (int i = 0; i < poleA.Length - 1; i++)
            {
                PocPor++;
                PocPri++;
                for (int j = 0; j < poleA.Length - i - 1; j++)
                {
                    PocPor++;
                    PocPri++;
                    if (poleA[j + 1] < poleA[j])
                    {
                        PocPor++;
                        int tmp = poleA[j + 1];
                        poleA[j + 1] = poleA[j];
                        poleA[j] = tmp;
                        PocPri += 3;
                        for (int k = 0; k < 20; k++)
                        {
                            S += poleA[k].ToString() + " ";
                        }
                        S = "";
                    }
                }
            }
            for (int i = 0; i < 20; i++)
                S += poleA[i].ToString() + " ";
            tbPolePo.Text = S;
            tBBublPorovnani.Text = PocPor.ToString();
            tBBublPrirazeni.Text = PocPri.ToString();
        }

        private void button3_Click(object sender, EventArgs e)  // INSERT SORT
        {
            string S = "";
            long PocPri = 0, PocPor = 0;
            for (int i = 0, l = poleB.Length - 1; i <= l; i++)
            {
                PocPor++;
                PocPri+=2;
                int j = i;
                int x = poleB[i];
                PocPri += 2;
                while ((j > 0) && (x < poleB[j - 1]))   // log spojky: && a soucasne platí, || znamená nebo
                {
                    PocPor += 2;
                    poleB[j] = poleB[j - 1];
                    j--;
                    PocPri += 2;
                }
                poleB[j] = x;
                PocPri++;
                for (int k = 0; k < 20; k++)
                {
                    S += poleB[k].ToString() + " ";
                }
                S = "";
            }
            for (int i = 0; i < 20; i++)
                S += poleB[i].ToString() + " ";
            tbPolePo.Text = S;
            tBInsertPorovnani.Text = PocPor.ToString();
            tBInsertPrirazeni.Text = PocPri.ToString();
        }

        private static void Vymena(ref int f, ref int s)  // ref je tady pouzito pro volani odkazem
        {
            int x = f;
            f = s;
            s = x;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tbPolePo.Text = "";
        }
    }
}
