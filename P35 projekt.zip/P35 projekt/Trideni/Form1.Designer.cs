﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbPolePred = new System.Windows.Forms.TextBox();
            this.tbPolePo = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tBBublPorovnani = new System.Windows.Forms.TextBox();
            this.tBInsertPorovnani = new System.Windows.Forms.TextBox();
            this.tBBublPrirazeni = new System.Windows.Forms.TextBox();
            this.tBInsertPrirazeni = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(212, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "Bublinkove trideni";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(43, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "pred serazenim:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(40, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "po serazeni:";
            // 
            // tbPolePred
            // 
            this.tbPolePred.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbPolePred.Location = new System.Drawing.Point(171, 152);
            this.tbPolePred.Name = "tbPolePred";
            this.tbPolePred.Size = new System.Drawing.Size(518, 26);
            this.tbPolePred.TabIndex = 3;
            // 
            // tbPolePo
            // 
            this.tbPolePo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tbPolePo.Location = new System.Drawing.Point(171, 194);
            this.tbPolePo.Name = "tbPolePo";
            this.tbPolePo.Size = new System.Drawing.Size(518, 26);
            this.tbPolePo.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(30, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(176, 54);
            this.button2.TabIndex = 5;
            this.button2.Text = "Nahodne generovat";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(374, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(156, 54);
            this.button3.TabIndex = 6;
            this.button3.Text = "Insert Sort trideni";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(241, 226);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(266, 54);
            this.button5.TabIndex = 8;
            this.button5.Text = "Vymazat serazene";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(66, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "Počet porovnání:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(66, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Počet přiřazení:";
            // 
            // tBBublPorovnani
            // 
            this.tBBublPorovnani.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBBublPorovnani.Location = new System.Drawing.Point(217, 85);
            this.tBBublPorovnani.Name = "tBBublPorovnani";
            this.tBBublPorovnani.Size = new System.Drawing.Size(139, 24);
            this.tBBublPorovnani.TabIndex = 11;
            this.tBBublPorovnani.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBInsertPorovnani
            // 
            this.tBInsertPorovnani.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBInsertPorovnani.Location = new System.Drawing.Point(374, 85);
            this.tBInsertPorovnani.Name = "tBInsertPorovnani";
            this.tBInsertPorovnani.Size = new System.Drawing.Size(139, 24);
            this.tBInsertPorovnani.TabIndex = 12;
            this.tBInsertPorovnani.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBBublPrirazeni
            // 
            this.tBBublPrirazeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBBublPrirazeni.Location = new System.Drawing.Point(217, 115);
            this.tBBublPrirazeni.Name = "tBBublPrirazeni";
            this.tBBublPrirazeni.Size = new System.Drawing.Size(139, 24);
            this.tBBublPrirazeni.TabIndex = 13;
            this.tBBublPrirazeni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBInsertPrirazeni
            // 
            this.tBInsertPrirazeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tBInsertPrirazeni.Location = new System.Drawing.Point(374, 116);
            this.tBInsertPrirazeni.Name = "tBInsertPrirazeni";
            this.tBInsertPrirazeni.Size = new System.Drawing.Size(139, 24);
            this.tBInsertPrirazeni.TabIndex = 14;
            this.tBInsertPrirazeni.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 293);
            this.Controls.Add(this.tBInsertPrirazeni);
            this.Controls.Add(this.tBBublPrirazeni);
            this.Controls.Add(this.tBInsertPorovnani);
            this.Controls.Add(this.tBBublPorovnani);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tbPolePo);
            this.Controls.Add(this.tbPolePred);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Radici algoritmy";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbPolePred;
        private System.Windows.Forms.TextBox tbPolePo;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tBBublPorovnani;
        private System.Windows.Forms.TextBox tBInsertPorovnani;
        private System.Windows.Forms.TextBox tBBublPrirazeni;
        private System.Windows.Forms.TextBox tBInsertPrirazeni;
    }
}

