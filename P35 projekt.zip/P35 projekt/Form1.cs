﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int[] pole = new int[20];

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random G = new Random();
            string S = "";
            for (int i = 0; i < 20; i++)
            {
                pole[i] = G.Next(100);
                S += pole[i].ToString()+" ";
            }
            tbPolePred.Text = S;
        }

        private void button1_Click(object sender, EventArgs e)  // SORT BUBBLE
        {
            string S = "";
            long PocPri = 0, PocPor = 0;
            for (int i = 0; i < pole.Length - 1; i++)
            {
                PocPor++;
                PocPri++;
                for (int j = 0; j < pole.Length - i - 1; j++)
                {
                    PocPor++;
                    PocPri++;
                    if (pole[j + 1] < pole[j])
                    {
                        PocPor++;
                        int tmp = pole[j + 1];
                        pole[j + 1] = pole[j];
                        pole[j] = tmp;
                        PocPri += 3;
                        for (int k = 0; k < 20; k++)
                        {
                            PocPor++;
                            PocPri++;
                            S += pole[k].ToString() + " ";
                            PocPri++;
                        }
                        //MessageBox.Show(S);
                        S = "";
                    }
                }
            }
            for (int i = 0; i < 20; i++)
                S += pole[i].ToString() + " ";
            tbPolePo.Text = S;
            tBBublPorovnani.Text = PocPor.ToString();
            tBBublPrirazeni.Text = PocPri.ToString();
        }

        private void button3_Click(object sender, EventArgs e)  // INSERT SORT
        {
            string S = "";
            long PocPri = 0, PocPor = 0;
            for (int i = 0, l = pole.Length - 1; i <= l; i++)
            {
                PocPor++;
                PocPri+=2;
                int j = i;
                int x = pole[i];
                PocPri += 2;
                while ((j > 0) && (x < pole[j - 1]))            // log spojky: && a soucasne platí, || znamená nebo
                {
                    PocPor += 2;
                    pole[j] = pole[j - 1];
                    j--;
                    PocPri += 2;
                }
                pole[j] = x;
                PocPri++;
                for (int k = 0; k < 20; k++)
                {
                    S += pole[k].ToString() + " ";
                }
                //MessageBox.Show(S);
                S = "";
            }
            for (int i = 0; i < 20; i++)
                S += pole[i].ToString() + " ";
            tbPolePo.Text = S;
            tBInsertPorovnani.Text = PocPor.ToString();
            tBInsertPrirazeni.Text = PocPri.ToString();
        }

        private static void Vymena(ref int f, ref int s)  // ref je tady pouzito pro volani odkazem
        {
            int x = f;
            f = s;
            s = x;
        }

        /*private void button4_Click(object sender, EventArgs e)      // PODEZRELE CHOVANI
        {
            string S = ""; 
            for (int i = pole.Length - 1; i > 0; i--)               // n-1 opakovani
            {
                                                                    // Nasledujici blok najde nejvyssi hodnotu v dosud nesetridene casti pole.
                int pmaxima = 0;                                    // pozice (aktualniho) maxima
                for (int j = i - 1; j >= 0; j--)                    // ((n-1)*n)/2 opakovani
                {
                    if (pole[j] > pole[pmaxima])
                    {
                        pmaxima = j;
                    }
                }
                                                                    // vymeni nalezenou nejvyssi hodnotu s krajni hodnotou
                Vymena(ref pole[pmaxima], ref pole[i]);
            }
            for (int i = 0; i < 20; i++)
                S += pole[i].ToString() + " ";
            tbPolePo.Text = S;
        }*/

        private void button5_Click(object sender, EventArgs e)
        {
            tbPolePo.Text = "";
        }
    }
}
