﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs eV)
        {
            string FILE_NAME = "";
            FILE_NAME = textBox1.Text;
            double cd;
            try
            {
                FileStream fs = new FileStream(FILE_NAME, FileMode.CreateNew);
                BinaryWriter w = new BinaryWriter(fs);
                for (int i = 1; i < 21; i++) // zapisujeme do souboru binárně čísla 1-20
                {
                    cd = (double)i;
                    w.Write(cd);   // ulozeni double každé číslo je na 8 bytech
                }
                w.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Chyba se souborem " + e.Message); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string FILE_NAME = "";
            FILE_NAME = textBox1.Text;
            richTextBox1.Text = "";
            FileStream fs = new FileStream(FILE_NAME, FileMode.Open, FileAccess.Read);
            BinaryReader r = new BinaryReader(fs);
            for (int i = 1; i < 21; i++)
            {
                richTextBox1.Text += (r.ReadDouble()).ToString()+" ";
                                      // čteme 8 bytu, hodnotu typu double
            }
            fs.Close();
        }
    }
}
