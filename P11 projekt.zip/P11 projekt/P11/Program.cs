﻿using System;

namespace ConsoleZlomky
{
    public class Zlomek
    {
        private int Jmenovatel, Citatel;
        float hodnota;
        public Zlomek(int cit, int jme)	  // konstruktor se 2 par typu int
        {
            Citatel = cit;
            if (jme != 0)			   // musíme zabránit dělení nulou
                Jmenovatel = jme;
            else
            {
                Jmenovatel = 1;
            }
            hodnota = (float)Citatel / Jmenovatel;
        }
        public Zlomek(int cislo) 		   // konstruktor s 1 par typu int
        {
            Citatel = cislo;
            Jmenovatel = 1;
            hodnota = (float)Citatel / Jmenovatel;
        }
        public Zlomek()		               // bezparametrický konstruktor
        {
            Citatel = 0;
            Jmenovatel = 1;
            hodnota = (float)Citatel / Jmenovatel;
        }

        public void NastavCit(int c)
        {
            Citatel = c;
            hodnota = (float)Citatel / Jmenovatel;
        }
        public void NastavJme(int j)
        {
            if (j != 0) Jmenovatel = j;
            hodnota = (float)Citatel / Jmenovatel;
        }
        public int DejCit()
        {
            return Citatel;
        }
        public int DejJme()
        {
            return Jmenovatel;
        }

        ~Zlomek()        // destruktor: znak tilda+jmeno tridy    ~Trida
        {
          Console.WriteLine("Ruším zlomek s hodnotou:" + 
                             this.Hodnota().ToString());
          Console.ReadLine();         
        }

        public float Hodnota()
        {
            return (float)Citatel / Jmenovatel;
        }

        public Zlomek(double number, double precision)      // konstruktor  pro dva double parametry
        {
        // Zlomek X = new Zlomek(3.141lf, 0.0001lf) - vysledek:  355 / 113
            int c=1, j=1;
            long krok = 0;	// počítáme si, kolik bude potřeba aproximaci
            while (Math.Abs((float)c/(float)j-number)>precision)
            {
                if ((float)c / (float)j > number)  // hodnota zlomku je 
                                                   // zatím vetsi nez cislo
                {
                    j++; // tedy zvetsime jmenovatel, abychom hodnotu 
                         // zmensili
                }
                else
                {
                    c++;      // a naopak zvetsime citatel, abychom hodnotu 
                              // zvetsili
                }
                krok++;
                hodnota = (float)c / j;
            }
            Citatel = c;
            Jmenovatel = j;
            hodnota = (float)Citatel / Jmenovatel;
        }

        public Zlomek Secti(Zlomek a, Zlomek b)
        {
            Zlomek v = new Zlomek(1, 2);
            v.NastavJme(a.Jmenovatel*b.Jmenovatel);
            v.NastavCit(a.Citatel*b.Jmenovatel+b.Citatel*a.Jmenovatel);
            return v;
        }
        
        public Zlomek Odecti(Zlomek a, Zlomek b)
        {
            Zlomek v = new Zlomek(1, 2);
            v.NastavJme(a.Jmenovatel * b.Jmenovatel);
            v.NastavCit(a.Citatel * b.Jmenovatel - b.Citatel * 
                        a.Jmenovatel);
            return v;
        }

        public Zlomek Soucin(Zlomek a, Zlomek b)
        {
            Zlomek v = new Zlomek(1, 2);
            v.NastavJme(a.Jmenovatel * b.Jmenovatel);
            v.NastavCit(a.Citatel * b.Citatel);
            return v;
        }

        public Zlomek Podil(Zlomek a, Zlomek b)
        {
            Zlomek v = new Zlomek(1, 2);
            v.NastavJme(a.Jmenovatel * b.Citatel);
            v.NastavCit(a.Citatel * b.Jmenovatel);
            return v;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Zlomek a = new Zlomek(3.141, 0.005);
            Zlomek b = new Zlomek(2.718, 0.005);
            Zlomek c = new Zlomek(1,1);
            
            Console.Write("Zlomek: "+a.DejCit().ToString()+
                          "/"+a.DejJme().ToString()+" ma hodnotu: ");
            Console.WriteLine(a.Hodnota());
            Console.Write("Zlomek: " + b.DejCit().ToString() +
                          "/" + b.DejJme().ToString() + " ma hodnotu: ");
            Console.WriteLine(b.Hodnota());

            c = c.Secti(a,b);
            Console.Write("Soucet: " + c.DejCit().ToString() + "/" + 
                          c.DejJme().ToString() + " ma hodnotu: ");
            Console.WriteLine(c.Hodnota());
            c = c.Odecti(a, b);
            Console.Write("Rozdil: " + c.DejCit().ToString() + "/" + 
                          c.DejJme().ToString() + " ma hodnotu: ");
            Console.WriteLine(c.Hodnota());
            c = c.Soucin(a, b);
            Console.Write("Soucin: " + c.DejCit().ToString() + "/" + 
                          c.DejJme().ToString() + " ma hodnotu: ");
            Console.WriteLine(c.Hodnota());
            c = c.Podil(a, b);
            Console.Write("Podil: " + c.DejCit().ToString() + "/" + 
                          c.DejJme().ToString() + " ma hodnotu: ");
            Console.WriteLine(c.Hodnota());

            Console.ReadLine();
        }
    }
}

