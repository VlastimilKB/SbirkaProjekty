﻿

using System;					// systémová knihovna

namespace ConsoleVypisRetezce			// jmenný prostor aplikace
{
    class Program
    {
        static void Main(string[] args)	// funkce Main, tj. start aplikace
        {
            Console.Write("hello world");	// výpis řetězce
            Console.Read();              // čtení z konzole, čekáme na Enter
        }
    }
}

